package com.fujitsu.cn.fnst.demo.modules;

import java.io.File;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.nutz.json.Json;
import org.nutz.lang.Streams;
import org.nutz.log.Log;
import org.nutz.log.Logs;
import org.nutz.mapl.Mapl;
import org.nutz.mvc.annotation.At;
import org.nutz.mvc.annotation.Fail;
import org.nutz.mvc.annotation.GET;
import org.nutz.mvc.annotation.Ok;
import org.nutz.mvc.annotation.Param;

@At("/productList")
@Ok("jsonp")
@Fail("json")
public class ProductListApiModule extends AbstractBaseModule {
	public final Log log = Logs.getLog(getClass());
	
	public static final Object productsJson = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/productlist/products.json")));

	
	
	@At("/products")
	@GET
	@Ok("jsonp")
	//@AdaptBy(type=JsonGetAdaptor.class)
	public Object alarmQuery(@Param("..") Map<String, Object> params) {
		log.debug(params);
		
		Integer startIndex = getInteger(params, "startIndex");
		Integer size = getInteger(params, "size");
		final String sortName = getString(params, "sortName");
		final String sortColName = getString(params, "sortColName");
		final String sortDir = getString(params, "sortDir");
		
		List<Map<String, String>> datas = Mapl.maplistToT(productsJson, List.class);
		
		int endIndex = startIndex + size;
		
		Collections.sort(datas, new Comparator<Map<String, String>>() {

			@Override
            public int compare(Map<String, String> o1, Map<String, String> o2) {
				int rt = 0;
				
				rt = compare(o1, o2, sortColName, sortDir);
				
				return rt;
            }
			
			private int compare(Map<String, String> o1, Map<String, String> o2, String fieldName, String dir) {
				String a = o1.get(fieldName);
				String b = o2.get(fieldName);
	            
				if (a == null && b == null) {
					return 0;
				}
				int rt = 0;
				if (a == null) {
					rt = -1;
				} else {
					rt = a.compareTo(b);
				}
				
	            return "des".equals(dir)?-rt:rt;
            }
		});
		
		if (endIndex > datas.size()) {
			endIndex = datas.size();
		}
		
		Map<String, Object> json = new HashMap<String, Object>();
		
		List returnList;
		if (endIndex < startIndex) {
			returnList = Collections.EMPTY_LIST;
		} else {
			returnList = datas.subList(startIndex, endIndex);
		}
		
		json.put("list", returnList);
		json.put("hitNum", datas.size());
		
		return json;
	}
}
