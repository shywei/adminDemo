package com.fujitsu.cn.fnst.demo.modules;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.nutz.json.Json;
import org.nutz.lang.Streams;
import org.nutz.log.Log;
import org.nutz.log.Logs;
import org.nutz.mapl.Mapl;
import org.nutz.mvc.adaptor.JsonAdaptor;
import org.nutz.mvc.annotation.AdaptBy;
import org.nutz.mvc.annotation.At;
import org.nutz.mvc.annotation.Fail;
import org.nutz.mvc.annotation.Ok;
import org.nutz.mvc.annotation.POST;
import org.nutz.mvc.annotation.Param;

/**
 * システム構成情報追加
 *
 */
@At("")
@Ok("jsonp")
@Fail("json")
public class CTR extends AbstractBaseModule
{
	public final Log log = Logs.getLog(getClass());
	public static final Object randomNum = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/randomNum.json")));
	public static final Object user_info = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/login.json")));
	public static final Object modifySystemUserPassword = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/modifySystemUserPassword.json")));
	public static final Object menu = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/menu.json")));
	public static final Object statistics = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/statistics.json")));
	public static final Object getUserList = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/getUserList.json")));
	public static final Object getUserFields = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/getUserFields.json")));
	public static final Object addUser = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/addUser.json")));
	public static final Object uploadPhoto = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/uploadPhoto.json")));
	public static final Object deleteUser = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/deleteUser.json")));
	public static final Object modifyUser = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/modifyUser.json")));
	public static final Object modifyUserState = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/modifyUserState.json")));
	public static final Object getDeptIdName = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/getDeptIdName.json")));
	public static final Object getCurrentRollCallList = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/getCurrentRollCallList.json")));
	public static final Object getRollCallDetails = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/getRollCallDetails.json")));
	public static final Object beginRollCall = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/beginRollCall.json")));
	public static final Object getRollCallStateInfo = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/getRollCallStateInfo.json")));
	public static final Object pauseRollCall = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/pauseRollCall.json")));
	public static final Object changeUserState = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/changeUserState.json")));
	public static final Object continueRollCall = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/continueRollCall.json")));
	public static final Object cancelRollCall = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/cancelRollCall.json")));
	public static final Object finishRollCall = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/finishRollCall.json")));
	public static final Object getRollCallFinishInfoList = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/getRollCallFinishInfoList.json")));
	public static final Object changeUserDept = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/changeUserDept.json")));
	public static final Object cancelChangeUserDept = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/cancelChangeUserDept.json")));
	public static final Object confirmChangeUserDept = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/confirmChangeUserDept.json")));
	public static final Object getOpLog = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/getOpLog.json")));
	public static final Object recentAttendanceData = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/recentAttendanceData.json")));
	public static final Object latestAbsentData = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/latestAbsentData.json")));
	public static final Object getDeviceList = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/getDeviceList.json")));
	public static final Object getDeviceAreaData = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/getDeviceAreaData.json")));
	public static final Object addDevice = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/addDevice.json")));
	public static final Object deleteDevice = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/deleteDevice.json")));
	public static final Object modifyDevice = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/modifyDevice.json")));
	public static final Object rebootDevice = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/rebootDevice.json")));
	public static final Object initializeDevice = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/initializeDevice.json")));
	public static final Object syncTime = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/syncTime.json")));
	public static final Object deviceState = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/deviceState.json")));
	public static final Object getDeviceInfo = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/getDeviceInfo.json")));
	public static final Object getSystemUserList = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/getSystemUserList.json")));
	public static final Object getRoleIdName = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/getRoleIdName.json")));
	public static final Object addSystemUser = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/addSystemUser.json")));
	public static final Object modifySystemUser = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/modifySystemUser.json")));
	public static final Object deleteSystemUser = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/deleteSystemUser.json")));
	public static final Object resetSystemUserPassword = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/resetSystemUserPassword.json")));
	public static final Object getDeptList = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/getDeptList.json")));
	public static final Object addDept = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/addDept.json")));
	public static final Object deleteDept = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/deleteDept.json")));
	public static final Object modifyDept = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/modifyDept.json")));
	public static final Object getRoleList = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/getRoleList.json")));
	public static final Object modifyRole = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/modifyRole.json")));
	public static final Object deleteRole = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/deleteRole.json")));
	public static final Object addRole = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/addRole.json")));
	public static final Object downloadAdmin = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/downloadAdmin.json")));
	public static final Object getDeviceNameData = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/getDeviceNameData.json")));
	public static final Object getRoleModelList = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/webapi/getRoleModelList.json")));
	
	//登录
	@At("/systemUser/login")
	@POST
	@AdaptBy(type=JsonAdaptor.class)
	@Ok("jsonp")
	public Object login(HttpServletRequest req,HttpServletResponse resp,@Param("..") Map<String, Object> params) {
	    resp.setHeader("Access-Control-Allow-Origin", "*");
        System.out.println("params: "+params);
        System.out.println("serverName: "+req.getServerName());
        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(user_info, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

	//验证码
	@At("/systemUser/randomNum")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object randomNum(HttpServletRequest req,HttpServletResponse resp,@Param("..") Map<String, Object> params) {
	    resp.setHeader("Access-Control-Allow-Origin", "*");
        System.out.println("params: "+params);
        System.out.println("serverName: "+req.getServerName());

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(randomNum, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

	//菜单
	@At("/authority/getMenuById")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object getMenuById(HttpServletRequest req,HttpServletResponse resp,@Param("..") Map<String, Object> params) {
	    resp.setHeader("Access-Control-Allow-Origin", "*");
        System.out.println("params: "+params);
        System.out.println("serverName: "+req.getServerName());
        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(menu, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }


	//修改密码
	@At("/systemUser/modifySystemUserPassword")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object modifySystemUserPassword(HttpServletRequest req,HttpServletResponse resp,@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(modifySystemUserPassword, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

	//首页统计
	@At("/main/statistics")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object statistics(HttpServletRequest req,HttpServletResponse resp,@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(statistics, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

	//获取人员列表
	@At("/user/getUserList")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object getUserList(HttpServletRequest req,HttpServletResponse resp,@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(getUserList, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

	//获取系统相关数据集（数据字典）
	@At("/user/getUserFields")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object getUserFields(HttpServletRequest req,HttpServletResponse resp,@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(getUserFields, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

	//登记人员
	@At("/user/addUser")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object addUser(HttpServletRequest req,HttpServletResponse resp,@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(addUser, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

	//上传照片
	@At("/user/uploadPhoto")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object uploadPhoto() {

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(uploadPhoto, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

	//删除人员
    @At("/user/deleteUser")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object deleteUser(HttpServletRequest req,HttpServletResponse resp,@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(deleteUser, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

  //修改人员信息
    @At("/user/modifyUser")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object modifyUser(HttpServletRequest req,HttpServletResponse resp,@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(modifyUser, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

  //变更人员状态
    @At("/user/modifyUserState")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object modifyUserState(HttpServletRequest req,HttpServletResponse resp,@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(modifyUserState, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

  //获取单位ID名称数据
    @At("/authority/getDeptIdName")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object getDeptIdName(HttpServletRequest req,HttpServletResponse resp,@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(getDeptIdName, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

  //当日工间点名信息列表
    @At("/rollCall/getCurrentRollCallList")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object getCurrentRollCallList(HttpServletRequest req,HttpServletResponse resp,@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(getCurrentRollCallList, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

  //点名详情
    @At("/rollCall/getRollCallDetails")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object getRollCallDetails(HttpServletRequest req,HttpServletResponse resp,@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(getRollCallDetails, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

  //开始点名
    @At("/rollCall/beginRollCall")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object beginRollCall(HttpServletRequest req,HttpServletResponse resp,@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(beginRollCall, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

  //点名进行中状态信息
    @At("/rollCall/getRollCallStateInfo")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object getRollCallStateInfo(HttpServletRequest req,HttpServletResponse resp,@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(getRollCallStateInfo, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

  //暂停点名
    @At("/rollCall/pauseRollCall")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object pauseRollCall(HttpServletRequest req,HttpServletResponse resp,@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(pauseRollCall, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

  //人员去向
    @At("/rollCall/changeUserState")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object changeUserState(HttpServletRequest req,HttpServletResponse resp,@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(changeUserState, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

  //继续点名
    @At("/rollCall/continueRollCall")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object continueRollCall(HttpServletRequest req,HttpServletResponse resp,@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(continueRollCall, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

  //取消点名
    @At("/rollCall/cancelRollCall")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object cancelRollCall(HttpServletRequest req,HttpServletResponse resp,@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(cancelRollCall, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

  //完成点名
    @At("/rollCall/finishRollCall")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object finishRollCall(HttpServletRequest req,HttpServletResponse resp,@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(finishRollCall, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

  //完成点名列表
    @At("/rollCall/getRollCallFinishInfoList")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object getRollCallFinishInfoList(HttpServletRequest req,HttpServletResponse resp,@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(getRollCallFinishInfoList, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

  //调队操作
    @At("/user/changeUserDept")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object changeUserDept(HttpServletRequest req,HttpServletResponse resp,@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(changeUserDept, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

  //撤回调队
    @At("/user/cancelChangeUserDept")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object cancelChangeUserDept(HttpServletRequest req,HttpServletResponse resp,@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(cancelChangeUserDept, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

    //确认调队
    @At("/user/confirmChangeUserDept")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object confirmChangeUserDept(HttpServletRequest req,HttpServletResponse resp,@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(confirmChangeUserDept, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

  //操作日志查询
    @At("/opLog/getOpLog")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object getOpLog(HttpServletRequest req,HttpServletResponse resp,@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(getOpLog, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

  //近期考勤数据
    @At("/main/recentAttendanceData")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object recentAttendanceData(HttpServletRequest req,HttpServletResponse resp,@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(recentAttendanceData, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

  //近期考勤数据
    @At("/main/latestAbsentData")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object latestAbsentData(HttpServletRequest req,HttpServletResponse resp,@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(latestAbsentData, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

  //获取设备列表（全部/条件）
    @At("/device/getDeviceList")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object getDeviceList(HttpServletRequest req,HttpServletResponse resp,@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(getDeviceList, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

  //设备位置数据
    @At("/device/getDeviceAreaData")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object getDeviceAreaData(@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(getDeviceAreaData, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

  //删除设备
    @At("/device/deleteDevice")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object deleteDevice(@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(deleteDevice, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

  //增加设备
    @At("/device/addDevice")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object addDevice(@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(addDevice, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

  //修改设备
    @At("/device/modifyDevice")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object modifyDevice(@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(modifyDevice, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

    //设备重启
    @At("/device/rebootDevice")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object rebootDevice(@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(rebootDevice, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

    //初始化设备
    @At("/device/initializeDevice")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object initializeDevice(@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(initializeDevice, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

    //时间同步
    @At("/device/syncTime")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object syncTime(@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(syncTime, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

    //状态检查
    @At("/device/deviceState")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object deviceState(@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(deviceState, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }

    //设备信息读取
    @At("/device/getDeviceInfo")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object getDeviceInfo(@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(getDeviceInfo, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }
    
  //查询系统用户列表（全部/条件）
    @At("/systemUser/getSystemUserList")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object getSystemUserList(@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(getSystemUserList, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }
    
  //获取角色ID名称数据
    @At("/authority/getRoleIdName")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object getRoleIdName(@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(getRoleIdName, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }
    
    //新增系统用户
    @At("/systemUser/addSystemUser")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object addSystemUser(@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(addSystemUser, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }
    
    //删除系统用户
    @At("/systemUser/deleteSystemUser")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object deleteSystemUser(@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(deleteSystemUser, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }
    
    //修改系统用户
    @At("/systemUser/modifySystemUser")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object modifySystemUser(@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(modifySystemUser, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }
    
    //重置用户密码
    @At("/systemUser/resetSystemUserPassword")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object resetSystemUserPassword(@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(resetSystemUserPassword, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }
    
  //增加单位
    @At("/authority/addDept")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object addDept(@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(addDept, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }
    
  //删除单位
    @At("/authority/deleteDept")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object deleteDept(@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(deleteDept, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }
    
  //修改单位
    @At("/authority/modifyDept")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object modifyDept(@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(modifyDept, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }
    
  //查询单位列表（条件）
    @At("/authority/getDeptList")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object getDeptList(@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(getDeptList, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }
    
    @At("/authority/getRoleList")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object getRoleList(@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(getRoleList, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }
    
    @At("/authority/modifyRole")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object modifyRole(@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(modifyRole, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }
    
    @At("/authority/deleteRole")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object deleteRole(@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(deleteRole, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }
    
    @At("/authority/addRole")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object addRole(@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(addRole, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }
    
    @At("/authority/downloadAdmin")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object downloadAdmin(@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(downloadAdmin, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }
    
    @At("/device/getDeviceNameData")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object getDeviceNameData(@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(getDeviceNameData, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }
    
    @At("/authority/getRoleModelList")
    @POST
    @AdaptBy(type=JsonAdaptor.class)
    @Ok("jsonp")
    public Object getRoleModelList(@Param("..") Map<String, Object> params) {

        System.out.println("params: "+params);

        Map<String, Object> InfdataoMap = (Map<String, Object>) Mapl.maplistToT(getRoleModelList, Map.class);

        try {
              Thread.sleep(1000);
          } catch (InterruptedException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
          }
        return InfdataoMap;
    }
}
