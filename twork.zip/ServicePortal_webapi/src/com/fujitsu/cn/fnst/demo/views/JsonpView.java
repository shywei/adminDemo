package com.fujitsu.cn.fnst.demo.views;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.nutz.json.Json;
import org.nutz.lang.Strings;
import org.nutz.mvc.View;

public class JsonpView implements View {
	public static final String DEFAULT_CALLBACK_STRING = "callback";
	private String callbackString;
	
	public JsonpView() {
	    this(DEFAULT_CALLBACK_STRING);
    }

	public JsonpView(String value) {
		if (Strings.isEmpty(value)) {
			value = DEFAULT_CALLBACK_STRING;
		}
	    this.callbackString = value;
    }

	@Override
    public void render(HttpServletRequest req, HttpServletResponse resp, Object obj)
            throws Throwable {
		String callbackName = req.getParameter(callbackString);
		resp.setContentType("application/javascript");
		if (callbackName == null) {
			Json.toJson(resp.getWriter(), obj);
		} else {
			resp.getWriter().print(callbackName);
			resp.getWriter().print("(");
			Json.toJson(resp.getWriter(), obj);
			resp.getWriter().print(");");
		}
		
    }

}
