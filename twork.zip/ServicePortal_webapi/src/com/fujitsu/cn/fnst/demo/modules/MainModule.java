package com.fujitsu.cn.fnst.demo.modules;

import org.nutz.mvc.annotation.Fail;
import org.nutz.mvc.annotation.IocBy;
import org.nutz.mvc.annotation.Localization;
import org.nutz.mvc.annotation.Modules;
import org.nutz.mvc.annotation.Views;
import org.nutz.mvc.ioc.provider.ComboIocProvider;

import com.fujitsu.cn.fnst.demo.views.JsonpViewMaker;


@Modules( packages = {"com.fujitsu.cn.fnst.demo.modules"},scanPackage=true)
@IocBy(type = ComboIocProvider.class, 
	args = {"*org.nutz.ioc.loader.json.JsonLoader",
			"config/",
			"*org.nutz.ioc.loader.annotation.AnnotationIocLoader",
			"com.fujitsu.cn.fnst.demo",
			}
)
@Localization("msg")
@Fail("json")
@Views({JsonpViewMaker.class})
public class MainModule {
	
}

