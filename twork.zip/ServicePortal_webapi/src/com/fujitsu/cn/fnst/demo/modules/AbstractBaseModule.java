package com.fujitsu.cn.fnst.demo.modules;

import org.nutz.castor.Castors;
import org.nutz.mapl.Mapl;

public abstract class AbstractBaseModule {

	
	protected Integer getInteger(Object json, String key) {
		return Castors.me().castTo(Mapl.cell(json, key), Integer.class);
	}
	
	protected String getString(Object json, String key) {
		return Castors.me().castTo(Mapl.cell(json, key), String.class);
	}
}
