package com.fujitsu.cn.fnst.demo.modules;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.nutz.log.Log;
import org.nutz.log.Logs;
import org.nutz.mapl.Mapl;
import org.nutz.mvc.adaptor.JsonAdaptor;
import org.nutz.mvc.annotation.AdaptBy;
import org.nutz.mvc.annotation.At;
import org.nutz.mvc.annotation.Fail;
import org.nutz.mvc.annotation.Ok;
import org.nutz.mvc.annotation.POST;
import org.nutz.mvc.annotation.Param;

@At("")
@Ok("jsonp")
@Fail("json")
public class ApiModule extends AbstractBaseModule {
	public final Log log = Logs.getLog(getClass());

	@At
	@POST
	@AdaptBy(type=JsonAdaptor.class)
	public Object login(HttpServletRequest req, HttpServletResponse resp,  @Param("..") Object params) {

		HashMap<String, Object> data = new HashMap<String, Object>();

		String name = (String)Mapl.cell(params, "name");
		String password = (String)Mapl.cell(params, "password");

		System.out.println("" + name + " : " + password);
		if ("001".equals(name) && "123".equals(password)) {
			data.put("errmsg", "");
		} else if ("002".equals(name) && "123".equals(password)) {
			data.put("errmsg", "");
		} else if ("fj".equals(name) && "123".equals(password)) {
			data.put("errmsg", "");
		} else if ("pfp001".equals(name) && "123".equals(password)) {
			data.put("errmsg", "");
		} else {
			data.put("errmsg", "用户名或密码不正确");
		}

		return data;
	}

}
