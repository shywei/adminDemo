package com.fujitsu.cn.fnst.demo.utils;

public interface Callable<T> {
	public boolean judge(T o);
}
