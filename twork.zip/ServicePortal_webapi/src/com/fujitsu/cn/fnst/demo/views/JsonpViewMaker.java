package com.fujitsu.cn.fnst.demo.views;

import org.nutz.ioc.Ioc;
import org.nutz.mvc.View;
import org.nutz.mvc.ViewMaker;

public class JsonpViewMaker implements ViewMaker {

	@Override
    public View make(Ioc ioc, String type, String value) {
    	if ("jsonp".equals(type)) {
    		return new JsonpView(value);
    	}
	    return null;
    }

}
