package com.fujitsu.cn.fnst.demo.adaptors;

import java.net.URLDecoder;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.nutz.json.Json;
import org.nutz.lang.Lang;
import org.nutz.mvc.adaptor.JsonAdaptor;

public class JsonGetAdaptor extends JsonAdaptor {
	@Override
	public Object getReferObject(ServletContext sc, HttpServletRequest req, HttpServletResponse resp, String[] pathArgs) {
		try {
			return Json.fromJson(URLDecoder.decode(req.getQueryString(), "UTF8"));
		} catch (Exception e) {
			throw Lang.wrapThrow(e);
		}
	}
}
