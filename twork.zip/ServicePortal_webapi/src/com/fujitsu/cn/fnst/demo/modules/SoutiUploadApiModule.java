package com.fujitsu.cn.fnst.demo.modules;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.nutz.json.Json;
import org.nutz.lang.Streams;
import org.nutz.mapl.Mapl;
import org.nutz.mvc.annotation.At;
import org.nutz.mvc.annotation.Fail;
import org.nutz.mvc.annotation.GET;
import org.nutz.mvc.annotation.Ok;
import org.nutz.mvc.annotation.Param;

@At("/soutilist")
@Ok("jsonp")
@Fail("json")
public class SoutiUploadApiModule {
	
	public static final Object contractJson = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/soutilistupload/errors.json")));

	@At("/contract")
	@GET
	@Ok("jsonp")
	public Object registerContract(@Param("..") Object params) {
		List<Map<String, String>> datas = Mapl.maplistToT(contractJson, List.class);
		Map<String, Object> json = new HashMap<String, Object>();
		
		json.put("updateResult", 1);
		json.put("rowCount", datas.size());
		json.put("list", datas);
		return json;
	}

}
