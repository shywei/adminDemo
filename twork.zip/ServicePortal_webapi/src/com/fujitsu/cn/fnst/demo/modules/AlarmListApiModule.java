package com.fujitsu.cn.fnst.demo.modules;

import java.io.File;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.nutz.json.Json;
import org.nutz.lang.Maths;
import org.nutz.lang.Streams;
import org.nutz.lang.Strings;
import org.nutz.log.Log;
import org.nutz.log.Logs;
import org.nutz.mapl.Mapl;
import org.nutz.mvc.annotation.At;
import org.nutz.mvc.annotation.Fail;
import org.nutz.mvc.annotation.GET;
import org.nutz.mvc.annotation.Ok;
import org.nutz.mvc.annotation.Param;

import com.fujitsu.cn.fnst.demo.utils.ArrayUtil;
import com.fujitsu.cn.fnst.demo.utils.Callable;

@At("")
@Ok("jsonp")
@Fail("json")
public class AlarmListApiModule extends AbstractBaseModule {
	public final Log log = Logs.getLog(getClass());
	
	public static final Object alarmsJson = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/alarmlist/alarms.json")));
	public static final Object usersJson = Json.fromJson(Streams.utf8r(ApiModule.class.getResourceAsStream("/data/alarmlist/users.json")));
	
	public static Object alarmsTimingJson = Json.fromJson("{"
			+ "		cycle : 0,"
			+ "		weekly_x_day_of_the_week : null,"
			+ "		monthly_x_date : null,"
			+ "		update_id : null,"
			+ "		update_date : null"
			+ "	}");

	
	
	@At("/alarmList/alarms")
	@GET
	@Ok("jsonp")
	//@AdaptBy(type=JsonGetAdaptor.class)
	public Object alarmQuery(@Param("..") Map<String, Object> params) {
		log.debug(params);
		
		Integer startIndex = getInteger(params, "startIndex")-1;
		Integer size = getInteger(params, "size");
		final String sortName = getString(params, "sortName");
		final String sortDir = getString(params, "sortDir");
		final String customerName = getString(params, "customerName");
		final String customerCode = getString(params, "customerCode");
		
		List<Map<String, String>> datas = Mapl.maplistToT(alarmsJson, List.class);
		
		datas = ArrayUtil.filter(datas, new Callable<Map<String, String>>() {

			@Override
            public boolean judge(Map<String, String> o) {
	            if (!Strings.isEmpty(customerCode)) {
	            	return Strings.equals(customerCode, o.get("customerCode"));
	            } else if (!Strings.isEmpty(customerName)){
	            	return o.get("customerName").contains(customerName);
	            }
	            return true;
            }
			
		});
		
		int endIndex = startIndex + size;
		
		Collections.sort(datas, new Comparator<Map<String, String>>() {

			@Override
            public int compare(Map<String, String> o1, Map<String, String> o2) {
				int rt = 0;
				
				rt = compare(o1, o2, sortName, sortDir);
				
				return rt;
            }
			
			private int compare(Map<String, String> o1, Map<String, String> o2, String fieldName, String dir) {
				String a = o1.get(fieldName);
				String b = o2.get(fieldName);
	            
				if (a == null && b == null) {
					return 0;
				}
				int rt = 0;
				if (a == null) {
					rt = -1;
				} else {
					rt = a.compareTo(b);
				}
				
	            return "des".equals(dir)?-rt:rt;
            }
		});
		
		if (endIndex > datas.size()) {
			endIndex = datas.size();
		}
		
		Map<String, Object> json = new HashMap<String, Object>();
		
		List returnList;
		if (endIndex < startIndex) {
			returnList = Collections.EMPTY_LIST;
		} else {
			returnList = datas.subList(startIndex, endIndex);
		}
		
		json.put("list", returnList);
		json.put("hitNum", datas.size());
		
		return json;
	}
	
	@At("/alarmList/machineUnconditionalitiesCsv")
	@GET
	@Ok("raw:text/csv")
	public Object machineUnconditionalitiesCsv(@Param("..") Map<String, Object> params) {
		log.debug(params);
		String file = getClass().getResource("/data/alarmlist/machineUnconditionalitiesCsv.csv").getFile();
		return new File(file);
	}
	
	@At("/alarmList/productInfosCsv")
	@GET
	@Ok("raw:text/csv")
	public Object productInfosCsv(@Param("..") Map<String, Object> params) {
		log.debug(params);
		String file = getClass().getResource("/data/alarmlist/productInfosCsv.csv").getFile();
		return new File(file);
	}
	
//	@At("/mail_opportunity/?")
//	@GET
//	@Ok("jsonp")
//	//@AdaptBy(type=JsonGetAdaptor.class)
//	public Object mailOpportunityGet(String login_id, @Param("..") Map<String, Object> params) {
//		log.debug("login id : " + login_id);
//		log.debug(params);
//		
//		return alarmsTimingJson;
//	}
//	
//	@At("/mail_opportunity/?")
//	@PUT
//	@Ok("jsonp")
//	@AdaptBy(type=JsonAdaptor.class)
//	public Object mailOpportunityUpdate(String login_id, @Param("..") Map<String, Object> params) {
//		log.debug("login id : " + login_id);
//		log.debug(params);
//		
//		alarmsTimingJson = Mapl.merge(alarmsTimingJson, params);
//		
//		return alarmsTimingJson;
//	}
	
	@At("/alarmList/users")
	@GET
	@Ok("jsonp")
	public Object users(@Param("..") Map<String, Object> params) {
		log.debug(params);
		final String employeeName = getString(params, "employeeName");
		final String mail = getString(params, "mail");
		String number = getString(params, "number");
		
		if (employeeName == null && mail == null) {
			return usersJson;
		}
		
		List<Map<String, Object>> list = Mapl.maplistToT(usersJson, List.class);
		List<Map<String, Object>> datas = ArrayUtil.filter(list, new Callable<Map<String, Object>>() {

			@Override
            public boolean judge(Map<String, Object> o) {
				
				
            	if (employeeName != null && getString(o, "employeeName").contains(employeeName)) {
            		return true;
            	} else if (mail != null && getString(o, "mail").contains(mail)) {
            		return true;
            	}
	            return false;
            }
		});
		
		HashMap<String, Object> json = new HashMap<String, Object>();
		int size = Strings.isEmpty(number)? datas.size() : Integer.parseInt(number);
		size = Maths.min(size, datas.size());
		json.put("hitNum", datas.size());
		json.put("list", datas.subList(0, size));
		
		return json;
	}
}
