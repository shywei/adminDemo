package com.fujitsu.cn.fnst.demo.utils;

import java.util.ArrayList;
import java.util.List;

public class ArrayUtil {
	/**
	 * 过滤list条件
	 * 
	 * @param list
	 * @param call 过滤方法。返回true时，加入到list中。
	 * @return
	 */
	public static <T> List<T> filter(List<T> list, Callable<T> call) {
		ArrayList<T> rt = new ArrayList<T>();
		for (T t : list) {
	        if (call.judge(t)) {
	        	rt.add(t);
	        }
        }
		return rt;
	}
}
