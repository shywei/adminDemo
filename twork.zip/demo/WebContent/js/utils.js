var utils;
window.utils=utils={
	//数据接口地址
	api_path:"http://localhost:8080/ServicePortal_webapi/api/",
	//api_path:"",

	//显示菜单
	getMenu:function(menuName,modelName){
		if(sessionStorage.menu==null){

		}else{
			var menu =JSON.parse(sessionStorage.menu);
			for(var i=0;i<menu.obj.length;i++){
				if(menu.obj[i].menuName==menuName){
					var code = '<li class="active"><a class="dropdown-collapse in" href="#"><i class="'+menu.obj[i].icon+'"></i> <span>'+menu.obj[i].menuName+'</span> <i class="icon-angle-down angle-down"></i> </a> <ul class="in nav nav-stacked">';
				}else{
					var code = '<li><a class="dropdown-collapse" href="#"><i class="'+menu.obj[i].icon+'"></i> <span>'+menu.obj[i].menuName+'</span> <i class="icon-angle-down angle-down"></i> </a> <ul class="nav nav-stacked">';
				}
				for(var m=0;m<menu.obj[i].model.length;m++){
					if(menu.obj[i].model[m].modelName==modelName){
						code =code+'<li class="active"><a href="'+menu.obj[i].model[m].modelUrl+'"> <i class="icon-caret-right"></i> <span>'+menu.obj[i].model[m].modelName+'</span></a></li>';
					}else{
						code =code+'<li class=""><a href="'+menu.obj[i].model[m].modelUrl+'"> <i class="icon-caret-right"></i> <span>'+menu.obj[i].model[m].modelName+'</span></a></li>';
					}
				}
				code =code+'</ul></li>';
				$("#menu").append(code);
			}
		}
	},

	//获取系统时间
	getTime:function(){
		var now=new Date();
		var year=now.getFullYear();
		var month=now.getMonth()+1;
		if(month<10){
			month="0"+month;
		}
		var day=now.getDate();
		if(day<10){
			day="0"+day;
		}
		var hours=now.getHours();
		if(hours<10){
			hours="0"+hours;
		}
		var minutes=now.getMinutes();
		if(minutes<10){
			minutes="0"+minutes;
		}
		var seconds=now.getSeconds();
		if(seconds<10){
			seconds="0"+seconds;
		}
		return year+"-"+month+"-"+day+" "+hours+":"+minutes+":"+seconds;
	},

	//设置下拉菜单选项
	setOptions:function(domId,item){
		if(sessionStorage.getItem(item)!=null){
			var data =JSON.parse(sessionStorage.getItem(item));
			for(var i=0;i<data.values.length;i++){
				$("#"+domId).append('<option value="'+data.values[i].fieldValue+'">'+data.values[i].fieldValueDisplay+'</option>');
			}
		}
	},

	//获取下拉菜单显示值
	getOptionName:function(item,value){
		if(sessionStorage.getItem(item)!=null){
			var data =JSON.parse(sessionStorage.getItem(item));
			for(var i=0;i<data.values.length;i++){
				if(data.values[i].fieldValue==value){
					return data.values[i].fieldValueDisplay;
				}
			}
		}
	},

	//设置所属单位下拉菜单选项
	setDeptOptions:function(domId){
		if(sessionStorage.getItem("depts")!=null){
			var data =JSON.parse(sessionStorage.getItem("depts"));
			for(var i=0;i<data.obj.length;i++){
				$("#"+domId).append('<option value="'+data.obj[i].deptId+'">'+data.obj[i].deptName+'</option>');
			}
		}
	},

	//获取单位名称
	getDeptName:function(value){
		if(sessionStorage.getItem("depts")!=null){
			var data =JSON.parse(sessionStorage.getItem("depts"));
			for(var i=0;i<data.obj.length;i++){
				if(data.obj[i].deptId==value){
					return data.obj[i].deptName;
				}
			}
		}
	},

	//获取单位数据
	getDept:function(root){
		$.ajax({
	        type: "post",
	        url: utils.api_path+"authority/getDeptIdName",
	        async:false,
	        dataType: "json",
	        contentType: "application/json;charset=utf-8",
	        data:JSON.stringify({loginUserId:JSON.parse(sessionStorage.userInfo).id,showRoot:root
	        }),
	        success: function (data) {
	        	if(data.code==0){
	        		sessionStorage.setItem("depts",JSON.stringify(data));
	        	}else{
	        		bootbox.alert({
	        		    message: data.message,
	        		    buttons: {
	        		        ok: {
	        		            label: '确定'
	        		        }
	        		    }
	        		});
	        	}
	        },
	        error: function (XMLHttpRequest, textStatus, errorThrown) {
	        	bootbox.alert({
        		    message: "获取单位ID名称数据请求发生错误！",
        		    buttons: {
        		        ok: {
        		            label: '确定'
        		        }
        		    }
        		});
	        }
	    });
	},
	
	//设置角色下拉菜单选项
	setRoleOptions:function(domId){
		if(sessionStorage.getItem("roles")!=null){
			var data =JSON.parse(sessionStorage.getItem("roles"));
			for(var i=0;i<data.obj.length;i++){
				$("#"+domId).append('<option value="'+data.obj[i].roleId+'">'+data.obj[i].roleName+'</option>');
			}
		}
	},

	//获取角色名称
	getRoleName:function(value){
		if(sessionStorage.getItem("roles")!=null){
			var data =JSON.parse(sessionStorage.getItem("roles"));
			for(var i=0;i<data.obj.length;i++){
				if(data.obj[i].roleId==value){
					return data.obj[i].roleName;
				}
			}
		}
	},

	//获取角色数据
	getRole:function(){
		$.ajax({
	        type: "post",
	        url: utils.api_path+"authority/getRoleIdName",
	        async:false,
	        dataType: "json",
	        contentType: "application/json;charset=utf-8",
	        data:JSON.stringify({loginUserId:JSON.parse(sessionStorage.userInfo).id
	        }),
	        success: function (data) {
	        	if(data.code==0){
	        		sessionStorage.setItem("roles",JSON.stringify(data));
	        	}else{
	        		bootbox.alert({
	        		    message: data.message,
	        		    buttons: {
	        		        ok: {
	        		            label: '确定'
	        		        }
	        		    }
	        		});
	        	}
	        },
	        error: function (XMLHttpRequest, textStatus, errorThrown) {
	        	bootbox.alert({
        		    message: "获取角色ID名称数据请求发生错误！",
        		    buttons: {
        		        ok: {
        		            label: '确定'
        		        }
        		    }
        		});
	        }
	    });
	},
	
	//获取设备名称数据（管理员下发用）
	getDeviceNameData:function(){
		$.ajax({
	        type: "post",
	        url: utils.api_path+"device/getDeviceNameData",
	        dataType: "json",
	        contentType: "application/json;charset=utf-8",
	        success: function (data) {
	        	if(data.code==0){
	        		sessionStorage.setItem("deviceNameData",JSON.stringify(data));
	        	}else{
	        		bootbox.alert({
	        		    message: data.message,
	        		    buttons: {
	        		        ok: {
	        		            label: '确定'
	        		        }
	        		    }
	        		});
	        	}
	        },
	        error: function (XMLHttpRequest, textStatus, errorThrown) {
	        	bootbox.alert({
        		    message: "获取设备名称数据请求发生错误！",
        		    buttons: {
        		        ok: {
        		            label: '确定'
        		        }
        		    }
        		});
	        }
	    });
	},

	//获取设备位置数据
	getArea:function(){
		$.ajax({
	        type: "post",
	        url: utils.api_path+"device/getDeviceAreaData",
	        async:false,
	        dataType: "json",
	        contentType: "application/json;charset=utf-8",
	        success: function (data) {
	        	if(data.code==0){
	        		sessionStorage.setItem("area",JSON.stringify(data));
	        	}else{
	        		bootbox.alert({
	        		    message: data.message,
	        		    buttons: {
	        		        ok: {
	        		            label: '确定'
	        		        }
	        		    }
	        		});
	        	}
	        },
	        error: function (XMLHttpRequest, textStatus, errorThrown) {
	        	bootbox.alert({
        		    message: "获取设备位置数据请求发生错误！",
        		    buttons: {
        		        ok: {
        		            label: '确定'
        		        }
        		    }
        		});
	        }
	    });
	},

	//获取位置名称
	getAreaName:function(value){
		if(sessionStorage.getItem("area")!=null){
			var data =JSON.parse(sessionStorage.getItem("area"));
			for(var i=0;i<data.obj.length;i++){
				if(data.obj[i].areaId==value){
					return data.obj[i].areaName;
				}
			}
		}
	},

	//设置设备位置下拉菜单选项
	setAreaOptions:function(domId){
		if(sessionStorage.getItem("area")!=null){
			var data =JSON.parse(sessionStorage.getItem("area"));
			for(var i=0;i<data.obj.length;i++){
				$("#"+domId).append('<option value="'+data.obj[i].areaId+'">'+data.obj[i].areaName+'</option>');
			}
		}
	},

	/**
	 * 计算百分比
	 * @param num
	 * @param total
	 * @returns
	 */
	getPercent:function (num, total) {
		num = parseFloat(num);
		total = parseFloat(total);
		if (isNaN(num) || isNaN(total)) {
		return "-";
		}
		return total <= 0 ? "0%" : (Math.round(num / total * 10000) / 100.00 + "%");
		}
};
