/**
 * palmpass控件plugin
 */
(function($) {

	// 插件方法
	$.fn.palmload = function(options) {

		var opts = $.extend({}, $.fn.palmload.defaults, options);

		try {

			var objectX;
			if (!!window.ActiveXObject || "ActiveXObject" in window){ // IE
				objectX = document.getElementById(opts.ieObjectXkey);
			} else {
				objectX = document.getElementById(opts.otherObjXKey);
			}
			//以下代码用于英文版系统,设置注册控件中英文使用,如只有中文版,请注释
			if(opts.palmLangKey ==='en_US'){	
                objectX.Pvs_SetLangType(1);
            }
			/*else if(opts.langKey==='zh_CN'){
                objectX.Pvs_SetLangType(0);
            }*/
			//以上代码用于英文版系统,设置注册控件中英文使用,如只有中文版,请注释
			var init = objectX.Pvs_InitCtrl();

			if (init.toString() == "1") {
				
				var load;

				if(opts.palmTypeKey == 'check'){
					load = objectX.Pvs_LoadLoginDialog();
				}else{
					// 设置黑名单比对模式
					if(opts.isIdentifyKey != "0"){
						objectX.Pvs_InitBlackListIdentify(opts.isIdentifyKey,opts.identifyIpKey,opts.identifyPortKey);
					}
					if(opts.whiteIsIdentifyKey == "1"){
						// 设置白名单比对模式
						objectX.Pvs_InitWhiteListIdentify(opts.whiteIsIdentifyKey,opts.identifyIpKey,opts.identifyPortKey,opts.whiteUserIdKey);
					}
					
					// 单手验证
					load = objectX.Pvs_EnrollSingleHand();
				}
				
				if (load.toString() == "1") {
					objectX.Pvs_CloseSensor();
					var veinData;
					if(opts.palmTypeKey == 'check'){
						veinData = objectX.Pvs_GetCaptureVeinData();
					}else{
						veinData = objectX.Pvs_GetEnrollVeinData();
					}		
					
					document.getElementById(opts.veinDataKey).value = veinData.toString();
					var captureData, blacklistData;
					//获取capture数据
					if(opts.isIdentifyKey == "2"){
						captureData = objectX.Pvs_GetBlackListCaptureData();
						document.getElementById(opts.captureDataKey).value = captureData.toString();
					}
					//黑名单比对返回数据
					if(opts.isIdentifyKey == "1"){
						blacklistData = objectX.Pvs_GetBlackListMatchUserInfoList();
						document.getElementById(opts.blacklistDataKey).value = blacklistData.toString();
					}
					//白名单比对返回数据
					if(opts.whiteIsIdentifyKey == "1"){
						whitelistData = objectX.Pvs_GetWhiteListMatchUserInfoList();
						document.getElementById(opts.whitelistDataKey).value = whitelistData.toString();
					}
					if(opts.palmLangKey ==='en_US'){
						$('#' + opts.veinDataMsgKey).html('Capture finish');
					}else{
						$('#' + opts.veinDataMsgKey).html(opts.veinDataMsg);
					}
				} else {
					objectX.Pvs_CloseSensor();
				}
			} else {
				objectX.Pvs_CloseSensor();
			}

		} catch (e) {
			if(opts.palmLangKey ==='en_US'){
				alert("Palm capture exception,check the palm device please.");
			}else{
				alert("掌静脉采集异常，请检查设备是否正常！");
			}
		} finally {
			objectX.Pvs_CloseSensor();
		}

	};

	// 插件参数默认值
	$.fn.palmload.defaults = {
		ieObjectXkey : 'myobj',
		otherObjXKey : 'myotherobj',
		veinDataKey : 'veinData',
		veinDataMsgKey : 'veinDataMsg',
		veinDataMsg : '采集完成',
		palmTypeKey:'check', //默认为验证 否则是注册
		isIdentifyKey : '0',
		identifyIpKey : ' ',
		identifyPortKey : '0',
		captureDataKey : 'captureData',
		blacklistDataKey : 'blacklistData',
		langKey :'',
		whiteIsIdentifyKey : '0',
		whitelistDataKey : 'whitelistData',
		whiteUserIdKey : ''
	};
	
	var getObjectX = function(options){
		var objectX = null;
		if (!!window.ActiveXObject || "ActiveXObject" in window){ // IE
			objectX = document.getElementById(options.ieObjectXkey);
		} else {
			objectX = document.getElementById(options.otherObjXKey);
		} 
		return objectX;
	};
	
	$.palmpass = {
			/*
			 * 通过浏览器的控件搜索设备
			 *  
			 *  返回值 result {code: , data: }
			 *  
			 *  code : 0  成功
			 *            1  控件版本错误
			 *            2  控件未安装
			 * data: 返回数据
			 * 
			 */
			searchDevice: function(timeout){
				var objectX = getObjectX($.fn.palmload.defaults);
				var result = {};
				if(objectX){
					 // var result =  "0033200   100 0 1  192.168.3.100  255.255.255.0    192.168.3.1 777712345600:04:09:16:18:06   101 0 1  192.168.3.100  255.255.255.0    192.168.3.1 777712345600:04:09:16:18:06   102 0 1  192.168.3.100  255.255.255.0    192.168.3.1 777712345600:04:09:16:18:06   103 0 1  192.168.3.100  255.255.255.0    192.168.3.1 777712345600:04:09:16:18:06   104 0 1  192.168.3.100  255.255.255.0    192.168.3.1 777712345600:04:09:16:18:06";   
					try{
							result.data = objectX.Pvs_SearchDevice(timeout);
							result.code = 0;
							return result;
					}catch(e){
						result.code = 2;
					}
				} else{
				    result.code = 1;
				}
				return result;
			},
			
			/*
			 * 通过浏览器的控件更新设备信息
			 *  
			 *  返回值 result {code: , data: }
			 *  
			 *  code : 0  成功
			 *            1  控件版本错误
			 *            2  控件未安装
			 * data: 返回数据
			 * 
			 */
			udpUpdate: function(deviceInfo){
				var objectX = getObjectX($.fn.palmload.defaults);
				var result  ={};
				if(objectX){	
					try{
						result.data =  objectX.Pvs_ConfigDeviceByUDP(deviceInfo.deviceIp, deviceInfo.subnetmask, deviceInfo.gateway, deviceInfo.devicePort, deviceInfo.password, deviceInfo.deviceId, deviceInfo.deviceType, deviceInfo.deviceModel, deviceInfo.deviceMAC);	
						result.code = 0;
					}catch(e){
						result.code = 2;
					}
				} else {
					result.code = 1;
				}		
				return result;
			}
	};
})(jQuery);