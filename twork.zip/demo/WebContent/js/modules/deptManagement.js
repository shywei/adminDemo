var deptList=null;
utils.getMenu("系统管理","单位管理");
utils.getDept(1);

//检索
function getdeptList(con){
	deptList=null;
	//获取单位列表
	var params ={
			deptName:$("#dept_name").val(),
			parentId:$("#parent_id").val(),
			pageSize:$("#per_page").val(),
		};
	$.ajax({
		type: "post",
		url: utils.api_path+"authority/getDeptList",
		dataType: "json",
		contentType: "application/json;charset=utf-8",
		data:JSON.stringify($.extend(params,con)),
		success: function (data) {
			if(data.code==0){
				deptList=data.obj;
				if(deptList.length==0){
					$("#data_area").hide();
					$("#no_data").show();
					return;
				}
				$("#table_select_all").prop('checked',false);
				$("#data_area").show();
				$("#no_data").hide();

				$("#table_body").empty();
				//表格显示
				for(var i =0;i<deptList.results.length;i++){
					var dept_data=deptList.results[i];
					$("#table_body").append('<tr><td><input type="checkbox" data-id="'+dept_data.deptId+'"></td><td>'+dept_data.deptName+'</td><td>'+dept_data.parent+'</td><td>'
							+dept_data.createTime+'</td><td>'+dept_data.updateTime+'</td><td>'+dept_data.memo+'</td></tr>');
				}

				$('#paging').paging({
					initPageNo : deptList.page.currentPage, // 初始页码
					totalPages : deptList.page.pageCount, //总页数
					totalCount : '合计' + deptList.page.recordCount + '条数据', // 条目总数
					jump : true //是否支持跳转
				});

				$("#firstPage").click(function() {
					getdeptList({pageNo:1});
				});
				$("#prePage").click(function() {
					getdeptList({pageNo:deptList.page.currentPage-1});
				});
				$("#nextPage").click(function() {
					getdeptList({pageNo:deptList.page.currentPage+1});
				});
				$("#lastPage").click(function() {
					getdeptList({pageNo:deptList.page.pageCount});
				});
				$("#jumpBtn").click(function() {
					getdeptList({pageNo:$("#jumpText").val()});
				});
				$("#pageSelect li").click(function() {
					getdeptList({pageNo:$(this).text()});
				});
			}else{
				$("#data_area").hide();
				$("#no_data").hide();
				bootbox.alert({
					message: data.message,
					buttons: {
						ok: {
							label: '确定'
						}
					}
				});
			}
		},
		error: function (XMLHttpRequest, textStatus, errorThrown) {
			$("#data_area").hide();
			$("#no_data").hide();
			bootbox.alert({
				message: "查询单位列表请求发生错误",
				buttons: {
					ok: {
						label: '确定'
					}
				}
			});
		}
	});
}

//获取选中的id
function getSelectIds(){
	var ids=[];
	if(deptList.results.length==0){
		return ids;
	}
	$("#table_body :checked").each(function(){
	    ids.push($(this).data("id"));
	  });
	return ids;
}

//获取选中的单位信息
function getSelectDept(){
	var ids=getSelectIds();
	for(var i=0;i<deptList.results.length;i++){
		if(deptList.results[i].deptId==ids[0]){
			return deptList.results[i];
		}
	}
}

$(document).ready(function() {
	//表格全选
	$("#table_select_all").click(function() {
		if($("#table_select_all").prop('checked')){
			$("#table_body :checkbox").prop("checked",true);
		}else{
			$("#table_body :checkbox").prop("checked",false);
		}

	});

	//增加单位
	$("#add").click(function() {
		//打开模态窗前，清空输入值和错误提示
		$("#input_dept_name").val("");
		$("#input_parent_id").val("");
		$("#input_memo").val("");
		
		$("label.text-error").hide();
		$(".text-error").removeClass("text-error");
		$("#myModalLabel").text("增加单位");

		$("#modal_edit").modal('show');
	});

	//修改单位
	$("#edit").click(function() {
		if(getSelectIds().length!=1){
			bootbox.alert({
    		    message: "必须且只能选择一条数据！",
    		    buttons: {
    		        ok: {
    		            label: '确定'
    		        }
    		    }
    		});
			return false;
		}
		var data =getSelectDept();
		//打开模态窗前，清空输入值和错误提示
		$("#input_dept_name").val(data.deptName);
		$("#input_parent").hide();
		$("#input_memo").val(data.memo);

		$("label.text-error").hide();
		$(".text-error").removeClass("text-error");
		$("#myModalLabel").text("修改单位");

		$("#modal_edit").modal('show');
	});

	//删除单位
	$("#delete").click(function(){
		if(getSelectIds().length!=1){
			bootbox.alert({
    		    message: "必须且只能选择一条数据！",
    		    buttons: {
    		        ok: {
    		            label: '确定'
    		        }
    		    }
    		});
			return false;
		}

		bootbox.confirm({
		    title: "删除单位",
		    message: "选定单位将被删除，请确认",
		    buttons: {
		        cancel: {
		            label: '取消'
		        },
		        confirm: {
		            label: '确定'
		        }
		    },
		    callback: function (result) {
		        if(result){
		        	$.ajax({
				        type: "post",
				        url: utils.api_path+"authority/deleteDept",
				        dataType: "json",
				        contentType: "application/json;charset=utf-8",
				        data:JSON.stringify({deptId:getSelectDept().deptId}),
				        success: function (data) {
				        	if(data.code==0){
				        		//删除成功后重新检索
				        		getdeptList({pageNo:1});
				        	}else{
				        		bootbox.alert({
				        		    message: data.message,
				        		    buttons: {
				        		        ok: {
				        		            label: '确定'
				        		        }
				        		    }
				        		});
				        	}
				        },
				        error: function (XMLHttpRequest, textStatus, errorThrown) {
				        	bootbox.alert({
			        		    message: "删除单位请求发生错误！",
			        		    buttons: {
			        		        ok: {
			        		            label: '确定'
			        		        }
			        		    }
			        		});
				        }
				    });
		        }
		    }
		});
	});	

	//编辑模态窗表单
	$("#edit_form").validate({
		rules : {
			input_dept_name : {
				required : true
			},
			input_memo : {
				maxlength : 64
			}
		},
		errorClass:"text-error",
		onclick:false,
		onfocusout:false,
		onkeyup:false,
		messages : {
			input_dept_name : {
				required : "请输入单位名"
			},
			input_memo : {
				maxlength : "最大长度64"
			}
		},
		success: function(label) {
		    console.log('success');
		},
		submitHandler : function(form) {
			var params={
					deptName :$("#input_dept_name").val(),
					memo :$("#input_memo").val()
	    	};
	    	if($("#myModalLabel").text()=="增加单位"){
	    		$.ajax({
			        type: "post",
			        url: utils.api_path+"authority/addDept",
			        dataType: "json",
			        contentType: "application/json;charset=utf-8",
			        data:JSON.stringify($.extend(params,{parentId:$("#input_parent_id").val()})),
			        success: function (data) {
			        	if(data.code==0){
			        		$("#modal_edit").modal('hide');
			        		//重新检索
			        		getdeptList({pageNo:1});
			        	}else{
			        		bootbox.alert({
			        		    message: data.message,
			        		    buttons: {
			        		        ok: {
			        		            label: '确定'
			        		        }
			        		    }
			        		});
			        	}
			        },
			        error: function (XMLHttpRequest, textStatus, errorThrown) {
			        	bootbox.alert({
		        		    message: "增加单位请求发生错误！",
		        		    buttons: {
		        		        ok: {
		        		            label: '确定'
		        		        }
		        		    }
		        		});
			        }
			    });
	    	}else{
	    		$.ajax({
			        type: "post",
			        url: utils.api_path+"authority/modifyDept",
			        dataType: "json",
			        contentType: "application/json;charset=utf-8",
			        data:JSON.stringify($.extend(params,{deptId:getSelectDept().deptId})),
			        success: function (data) {
			        	if(data.code==0){
			        		$("#modal_edit").modal('hide');
			        		//重新检索
			        		getdeptList({pageNo:1});
			        	}else{
			        		bootbox.alert({
			        		    message: data.message,
			        		    buttons: {
			        		        ok: {
			        		            label: '确定'
			        		        }
			        		    }
			        		});
			        	}
			        },
			        error: function (XMLHttpRequest, textStatus, errorThrown) {
			        	bootbox.alert({
		        		    message: "修改用户请求发生错误！",
		        		    buttons: {
		        		        ok: {
		        		            label: '确定'
		        		        }
		        		    }
		        		});
			        }
			    });
	    	}
	    }
	});

	//查询表单
	$("#search_form").validate({
		rules : {
		},
		errorClass:"text-error",
		messages : {
		},
		submitHandler : function(form) {
			getdeptList({pageNo:1});
		}
	});

	//改变每页件数，触发查询
	$("#per_page").change(function() {
		getdeptList({pageNo:1});
	});

	//下拉列表选项
	utils.setDeptOptions("parent_id");
	utils.setDeptOptions("input_parent_id");
	utils.setOptions("per_page","pageSize");

	//初期查询
	getdeptList({pageNo:1});
});