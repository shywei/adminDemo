var userList=null;
utils.getMenu("戒毒人员","接收人员");
utils.getDept(0);

//检索
function getUserList(con){
	userList=null;
	//获取人员列表
	var params ={
			userName:$("#user_name").val(),
			officalNumber:$("#offical_number").val(),
			createTime :$("#create_time").val(),
			deptId:$("#dept_id").val(),
			confirmChangeDept:1,
			pageSize:$("#per_page").val(),
		};
	$.ajax({
		type: "post",
		url: utils.api_path+"user/getUserList",
		dataType: "json",
		contentType: "application/json;charset=utf-8",
		data:JSON.stringify($.extend(params,con)),
		success: function (data) {
			if(data.code==0){
				userList=data.obj;
				if(userList.results.length==0){
					$("#data_area").hide();
					$("#no_data").show();
					return;
				}
				$("#table_select_all").prop('checked',false);
				$("#data_area").show();
				$("#no_data").hide();

				$("#table_body").empty();
				//表格显示
				for(var i =0;i<userList.results.length;i++){
					var user_data=userList.results[i];
					$("#table_body").append('<tr><td><input type="checkbox" data-id="'+user_data.id+'"></td><td>'+user_data.userName+'</td><td>'+user_data.officalNumber
							+'</td><td>'+utils.getOptionName("reviseState", user_data.reviseState)+'</td><td>'+utils.getDeptName(user_data.receiveDeptId)+'</td><td>'+user_data.createTime+'</td><td>'+utils.getDeptName(user_data.deptId)+'</td><td>'+user_data.updateTime
							+'</td><td>'+utils.getOptionName("hasMetacarpalVein", user_data.hasMetacarpalVein)+'</td></tr>');
				}

				$('#paging').paging({
					initPageNo : userList.page.currentPage, // 初始页码
					totalPages : userList.page.pageCount, //总页数
					totalCount : '合计' + userList.page.recordCount + '条数据', // 条目总数
					jump : true //是否支持跳转
				});

				$("#firstPage").click(function() {
					getUserList({pageNo:1});
				});
				$("#prePage").click(function() {
					getUserList({pageNo:userList.page.currentPage-1});
				});
				$("#nextPage").click(function() {
					getUserList({pageNo:userList.page.currentPage+1});
				});
				$("#lastPage").click(function() {
					getUserList({pageNo:userList.page.pageCount});
				});
				$("#jumpBtn").click(function() {
					getUserList({pageNo:$("#jumpText").val()});
				});
				$("#pageSelect li").click(function() {
					getUserList({pageNo:$(this).text()});
				});
			}else{
				$("#data_area").hide();
				$("#no_data").hide();
				bootbox.alert({
					message: data.message,
					buttons: {
						ok: {
							label: '确定'
						}
					}
				});
			}
		},
		error: function (XMLHttpRequest, textStatus, errorThrown) {
			$("#data_area").hide();
			$("#no_data").hide();
			bootbox.alert({
				message: "获取人员列表请求发生错误",
				buttons: {
					ok: {
						label: '确定'
					}
				}
			});
		}
	});
}

//获取选中的id
function getSelectIds(){
	var ids=[];
	if(userList.results.length==0){
		return ids;
	}
	$("#table_body :checked").each(function(){
	    ids.push($(this).data("id"));
	  });
	return ids;
}

//获取选中的用户信息
function getSelectUser(){
	var ids=getSelectIds();
	for(var i=0;i<userList.results.length;i++){
		if(userList.results[i].id==ids[0]){
			return userList.results[i];
		}
	}
}

$(document).ready(function() {
	//表格全选
	$("#table_select_all").click(function() {
		if($("#table_select_all").prop('checked')){
			$("#table_body :checkbox").prop("checked",true);
		}else{
			$("#table_body :checkbox").prop("checked",false);
		}

	});

	//接收人员
	$("#accept").click(function() {
		if(getSelectIds().length==0){
			bootbox.alert({
    		    message: "未选中任何人员！",
    		    buttons: {
    		        ok: {
    		            label: '确定'
    		        }
    		    }
    		});
			return false;
		}

		bootbox.confirm({
		    title: "接收人员",
		    message: "选定人员调队操作将进行，请确认",
		    buttons: {
		        cancel: {
		            label: '取消'
		        },
		        confirm: {
		            label: '确定'
		        }
		    },
		    callback: function (result) {
		        if(result){
		        	$.ajax({
				        type: "post",
				        url: utils.api_path+"user/confirmChangeUserDept",
				        dataType: "json",
				        contentType: "application/json;charset=utf-8",
				        data:JSON.stringify({userIds:getSelectIds().join(",")}),
				        success: function (data) {
				        	if(data.code==0){
				        		//接收人员成功后重新检索
				        		getUserList({pageNo:1});
				        	}else{
				        		bootbox.alert({
				        		    message: data.message,
				        		    buttons: {
				        		        ok: {
				        		            label: '确定'
				        		        }
				        		    }
				        		});
				        	}
				        },
				        error: function (XMLHttpRequest, textStatus, errorThrown) {
				        	bootbox.alert({
			        		    message: "接收人员请求发生错误！",
			        		    buttons: {
			        		        ok: {
			        		            label: '确定'
			        		        }
			        		    }
			        		});
				        }
				    });
		        }
		    }
		});
	});

	//驳回申请
	$("#reject").click(function(){
		if(getSelectIds().length==0){
			bootbox.alert({
    		    message: "未选中任何人员！",
    		    buttons: {
    		        ok: {
    		            label: '确定'
    		        }
    		    }
    		});
			return false;
		}

		bootbox.confirm({
		    title: "驳回申请",
		    message: "选定人员调队申请将驳回，请确认",
		    buttons: {
		        cancel: {
		            label: '取消'
		        },
		        confirm: {
		            label: '确定'
		        }
		    },
		    callback: function (result) {
		        if(result){
		        	$.ajax({
				        type: "post",
				        url: utils.api_path+"user/cancelChangeUserDept",
				        dataType: "json",
				        contentType: "application/json;charset=utf-8",
				        data:JSON.stringify({userIds:getSelectIds().join(",")}),
				        success: function (data) {
				        	if(data.code==0){
				        		//驳回申请成功后重新检索
				        		getUserList({pageNo:1});
				        	}else{
				        		bootbox.alert({
				        		    message: data.message,
				        		    buttons: {
				        		        ok: {
				        		            label: '确定'
				        		        }
				        		    }
				        		});
				        	}
				        },
				        error: function (XMLHttpRequest, textStatus, errorThrown) {
				        	bootbox.alert({
			        		    message: "驳回申请请求发生错误！",
			        		    buttons: {
			        		        ok: {
			        		            label: '确定'
			        		        }
			        		    }
			        		});
				        }
				    });
		        }
		    }
		});
	});

	//日历控件初始化
	$('.form_date').datetimepicker({
		language:  'zh-CN',
		weekStart: 1,
		todayBtn:  1,
		autoclose: 1,
		todayHighlight: 1,
		startView: 2,
		minView: 2,
		forceParse: 0
	});

	//查询表单
	$("#search_form").validate({
		rules : {
			user_name : {
				maxlength : 10
			},
			offical_number : {
				maxlength : 10
			}
		},
		errorClass:"text-error",
		messages : {
			user_name : {
				maxlength : "用户名最长十位"
			},
			offical_number : {
				maxlength : "所编号最长十位"
			}
		},
		submitHandler : function(form) {
			getUserList({pageNo:1});
		}
	});

	//改变每页件数，触发查询
	$("#per_page").change(function() {
		getUserList({pageNo:1});
	});

	//下拉列表选项
	utils.setOptions("user_state","userState");
	utils.setOptions("per_page","pageSize");
	utils.setDeptOptions("dept_id");

	//初期查询
	getUserList({pageNo:1});
});