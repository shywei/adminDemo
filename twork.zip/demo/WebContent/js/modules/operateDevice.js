var deviceList=null;
utils.getMenu("设备管理","管理设备");
utils.getArea();

//检索
function getDeviceList(con){
	deviceList=null;
	//获取设备列表
	var params ={
			deviceName:$("#device_name").val(),
			deviceId:$("#device_id").val(),
			deviceIp :$("#device_ip").val(),
			deviceStatus :$("#device_status").val(),
			pageSize:$("#per_page").val(),
		};
	$.ajax({
		type: "post",
		url: utils.api_path+"device/getDeviceList",
		dataType: "json",
		contentType: "application/json;charset=utf-8",
		data:JSON.stringify($.extend(params,con)),
		success: function (data) {
			if(data.code==0){
				deviceList=data.obj;
				if(deviceList.results.length==0){
					$("#data_area").hide();
					$("#no_data").show();
					return;
				}
				$("#table_select_all").prop('checked',false);
				$("#data_area").show();
				$("#no_data").hide();

				$("#table_body").empty();
				//表格显示
				for(var i =0;i<deviceList.results.length;i++){
					var device_data=deviceList.results[i];
					$("#table_body").append('<tr><td><input type="checkbox" data-id="'+device_data.deviceId+'"></td><td>'+device_data.deviceId+'</td><td>'+device_data.deviceName+'</td><td>'+device_data.deviceIp
							+'</td><td>'+utils.getOptionName("deviceModel",device_data.deviceModel)+'</td><td>'+utils.getOptionName("deviceState", device_data.deviceStatus)+'</td><td>'+utils.getOptionName("applicationModel", device_data.applicationModel)
							+'</td><td>'+device_data.operationType+'</td><td>'+device_data.operatorResult
							+'</td><td>'+utils.getAreaName( device_data.areaId)+'</td></tr>');
				}

				$('#paging').paging({
					initPageNo : deviceList.page.currentPage, // 初始页码
					totalPages : deviceList.page.pageCount, //总页数
					totalCount : '合计' + deviceList.page.recordCount + '条数据', // 条目总数
					jump : true //是否支持跳转
				});

				$("#firstPage").click(function() {
					getDeviceList({pageNo:1});
				});
				$("#prePage").click(function() {
					getDeviceList({pageNo:deviceList.page.currentPage-1});
				});
				$("#nextPage").click(function() {
					getDeviceList({pageNo:deviceList.page.currentPage+1});
				});
				$("#lastPage").click(function() {
					getDeviceList({pageNo:deviceList.page.pageCount});
				});
				$("#jumpBtn").click(function() {
					getDeviceList({pageNo:$("#jumpText").val()});
				});
				$("#pageSelect li").click(function() {
					getDeviceList({pageNo:$(this).text()});
				});
			}else{
				$("#data_area").hide();
				$("#no_data").hide();
				bootbox.alert({
					message: data.message,
					buttons: {
						ok: {
							label: '确定'
						}
					}
				});
			}
		},
		error: function (XMLHttpRequest, textStatus, errorThrown) {
			$("#data_area").hide();
			$("#no_data").hide();
			bootbox.alert({
				message: "获取设备列表请求发生错误",
				buttons: {
					ok: {
						label: '确定'
					}
				}
			});
		}
	});
}

//获取选中的id
function getSelectIds(){
	var ids=[];
	if(deviceList.results.length==0){
		return ids;
	}
	$("#table_body :checked").each(function(){
	    ids.push($(this).data("id"));
	  });
	return ids;
}

//获取选中的设备信息
function getSelectDevice(){
	var ids=getSelectIds();
	for(var i=0;i<deviceList.results.length;i++){
		if(deviceList.results[i].deviceId==ids[0]){
			return deviceList.results[i];
		}
	}
}

$(document).ready(function() {
	//表格全选
	$("#table_select_all").click(function() {
		if($("#table_select_all").prop('checked')){
			$("#table_body :checkbox").prop("checked",true);
		}else{
			$("#table_body :checkbox").prop("checked",false);
		}

	});

	//设备重启
	$("#reboot").click(function() {
		if(getSelectIds().length!=1){
			bootbox.alert({
    		    message: "必须且只能选择一条数据！",
    		    buttons: {
    		        ok: {
    		            label: '确定'
    		        }
    		    }
    		});
			return false;
		}
		bootbox.confirm({
		    title: "设备重启",
		    message: "选定设备将进行重启，请确认",
		    buttons: {
		        cancel: {
		            label: '取消'
		        },
		        confirm: {
		            label: '确定'
		        }
		    },
		    callback: function (result) {
		        if(result){
		        	$.ajax({
				        type: "post",
				        url: utils.api_path+"device/rebootDevice",
				        dataType: "json",
				        contentType: "application/json;charset=utf-8",
				        data:JSON.stringify({deviceId:getSelectIds()[0]}),
				        success: function (data) {
				        	if(data.code==0){
				        		//删除成功后重新检索
				        		getDeviceList({pageNo:1});
				        	}else{
				        		bootbox.alert({
				        		    message: data.message,
				        		    buttons: {
				        		        ok: {
				        		            label: '确定'
				        		        }
				        		    }
				        		});
				        	}
				        },
				        error: function (XMLHttpRequest, textStatus, errorThrown) {
				        	bootbox.alert({
			        		    message: "设备重启请求发生错误！",
			        		    buttons: {
			        		        ok: {
			        		            label: '确定'
			        		        }
			        		    }
			        		});
				        }
				    });
		        }
		    }
		});
	});

	//初始化设备
	$("#initialize").click(function() {
		if(getSelectIds().length!=1){
			bootbox.alert({
    		    message: "必须且只能选择一条数据！",
    		    buttons: {
    		        ok: {
    		            label: '确定'
    		        }
    		    }
    		});
			return false;
		}
		bootbox.confirm({
		    title: "初始化设备",
		    message: "选定设备将进行初始化，请确认",
		    buttons: {
		        cancel: {
		            label: '取消'
		        },
		        confirm: {
		            label: '确定'
		        }
		    },
		    callback: function (result) {
		        if(result){
		        	$.ajax({
				        type: "post",
				        url: utils.api_path+"device/initializeDevice",
				        dataType: "json",
				        contentType: "application/json;charset=utf-8",
				        data:JSON.stringify({deviceId:getSelectIds()[0]}),
				        success: function (data) {
				        	if(data.code==0){
				        		//删除成功后重新检索
				        		getDeviceList({pageNo:1});
				        	}else{
				        		bootbox.alert({
				        		    message: data.message,
				        		    buttons: {
				        		        ok: {
				        		            label: '确定'
				        		        }
				        		    }
				        		});
				        	}
				        },
				        error: function (XMLHttpRequest, textStatus, errorThrown) {
				        	bootbox.alert({
			        		    message: "初始化设备请求发生错误！",
			        		    buttons: {
			        		        ok: {
			        		            label: '确定'
			        		        }
			        		    }
			        		});
				        }
				    });
		        }
		    }
		});
	});

	//时间同步
	$("#sync").click(function() {
		if(getSelectIds().length!=1){
			bootbox.alert({
    		    message: "必须且只能选择一条数据！",
    		    buttons: {
    		        ok: {
    		            label: '确定'
    		        }
    		    }
    		});
			return false;
		}
		bootbox.confirm({
		    title: "时间同步",
		    message: "选定设备将进行时间同步，请确认",
		    buttons: {
		        cancel: {
		            label: '取消'
		        },
		        confirm: {
		            label: '确定'
		        }
		    },
		    callback: function (result) {
		        if(result){
		        	$.ajax({
				        type: "post",
				        url: utils.api_path+"device/syncTime",
				        dataType: "json",
				        contentType: "application/json;charset=utf-8",
				        data:JSON.stringify({deviceId:getSelectIds()[0]}),
				        success: function (data) {
				        	if(data.code==0){
				        		//删除成功后重新检索
				        		getDeviceList({pageNo:1});
				        	}else{
				        		bootbox.alert({
				        		    message: data.message,
				        		    buttons: {
				        		        ok: {
				        		            label: '确定'
				        		        }
				        		    }
				        		});
				        	}
				        },
				        error: function (XMLHttpRequest, textStatus, errorThrown) {
				        	bootbox.alert({
			        		    message: "时间同步请求发生错误！",
			        		    buttons: {
			        		        ok: {
			        		            label: '确定'
			        		        }
			        		    }
			        		});
				        }
				    });
		        }
		    }
		});
	});

	//状态检查
	$("#check_state").click(function() {
		if(getSelectIds().length!=1){
			bootbox.alert({
    		    message: "必须且只能选择一条数据！",
    		    buttons: {
    		        ok: {
    		            label: '确定'
    		        }
    		    }
    		});
			return false;
		}
		bootbox.confirm({
		    title: "状态检查",
		    message: "选定设备将进行状态检查，请确认",
		    buttons: {
		        cancel: {
		            label: '取消'
		        },
		        confirm: {
		            label: '确定'
		        }
		    },
		    callback: function (result) {
		        if(result){
		        	$.ajax({
				        type: "post",
				        url: utils.api_path+"device/deviceState",
				        dataType: "json",
				        contentType: "application/json;charset=utf-8",
				        data:JSON.stringify({deviceId:getSelectIds()[0]}),
				        success: function (data) {
				        	if(data.code==0){
				        		//删除成功后重新检索
				        		getDeviceList({pageNo:1});
				        	}else{
				        		bootbox.alert({
				        		    message: data.message,
				        		    buttons: {
				        		        ok: {
				        		            label: '确定'
				        		        }
				        		    }
				        		});
				        	}
				        },
				        error: function (XMLHttpRequest, textStatus, errorThrown) {
				        	bootbox.alert({
			        		    message: "状态检查请求发生错误！",
			        		    buttons: {
			        		        ok: {
			        		            label: '确定'
			        		        }
			        		    }
			        		});
				        }
				    });
		        }
		    }
		});
	});

	//设备信息读取
	$("#get_info").click(function() {
		if(getSelectIds().length!=1){
			bootbox.alert({
    		    message: "必须且只能选择一条数据！",
    		    buttons: {
    		        ok: {
    		            label: '确定'
    		        }
    		    }
    		});
			return false;
		}
		bootbox.confirm({
		    title: "设备信息读取",
		    message: "选定设备将进行设备信息读取，请确认",
		    buttons: {
		        cancel: {
		            label: '取消'
		        },
		        confirm: {
		            label: '确定'
		        }
		    },
		    callback: function (result) {
		        if(result){
		        	$.ajax({
				        type: "post",
				        url: utils.api_path+"device/getDeviceInfo",
				        dataType: "json",
				        contentType: "application/json;charset=utf-8",
				        data:JSON.stringify({deviceId:getSelectIds()[0]}),
				        success: function (data) {
				        	if(data.code==0){
				        		//删除成功后重新检索
				        		getDeviceList({pageNo:1});
				        	}else{
				        		bootbox.alert({
				        		    message: data.message,
				        		    buttons: {
				        		        ok: {
				        		            label: '确定'
				        		        }
				        		    }
				        		});
				        	}
				        },
				        error: function (XMLHttpRequest, textStatus, errorThrown) {
				        	bootbox.alert({
			        		    message: "设备信息读取请求发生错误！",
			        		    buttons: {
			        		        ok: {
			        		            label: '确定'
			        		        }
			        		    }
			        		});
				        }
				    });
		        }
		    }
		});
	});

	//查询表单
	$("#search_form").validate({
		rules : {
		},
		errorClass:"text-error",
		messages : {
		},
		submitHandler : function(form) {
			getDeviceList({pageNo:1});
		}
	});

	//下拉列表选项
	utils.setOptions("device_status","deviceState");
	utils.setOptions("per_page","pageSize");

	//改变每页件数，触发查询
	$("#per_page").change(function() {
		getDeviceList({pageNo:1});
	});

	//初期查询
	getDeviceList({pageNo:1});
});