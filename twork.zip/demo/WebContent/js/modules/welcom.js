utils.getMenu("","");
$(function() {
	//欢迎消息
	var now=new Date();
	var year=now.getFullYear();
	var month=now.getMonth();
	var date=now.getDate();
	var day=now.getDay();
	var week = new Array("星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六");
	$("#welcom_info").text("欢迎使用人员管理系统，今天是"+year+"年"+month+"月"+date+"，"+week[day]);

	//统计数据
	$.ajax({
        type: "post",
        url: utils.api_path+"main/statistics",
        dataType: "json",
        contentType: "application/json;charset=utf-8",
        data:JSON.stringify({userId:JSON.parse(sessionStorage.userInfo).id
        }),
        success: function (data) {
        	if(data.code==0){
        		$("#registered_num").text(data.obj.registeredNum);
        		$("#extant_num").text(data.obj.extantNum);
        		$("#external_medical_treatment").text(data.obj.externalMedicalTreatment);
        		$("#roll_call_num").text(data.obj.rollCallNum);
        		$("#no_metacarpal_vein").text(data.obj.noMetacarpalVein);
        		$("#no_photo").text(data.obj.noPhoto);
        		$("#abnormal_device").text(data.obj.abnormalDevice);
        	}else{
        		bootbox.alert({
        		    message: data.message,
        		    buttons: {
        		        ok: {
        		            label: '确定'
        		        }
        		    },
        		    callback: function (result) {
        		    }
        		});
        	}
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
        	bootbox.alert({
    		    message: "统计数据请求发生错误",
    		    buttons: {
    		        ok: {
    		            label: '确定'
    		        }
    		    }
    		});
        }
    });

	//近期考勤数据
	$.ajax({
        type: "post",
        url: utils.api_path+"main/recentAttendanceData",
        dataType: "json",
        contentType: "application/json;charset=utf-8",
        data:JSON.stringify({userId:JSON.parse(sessionStorage.userInfo).id
        }),
        success: function (data) {
        	if(data.code==0){
        		var categories=[];
        		var extant=[];
        		var rollCall=[];
        		var attend=[];
        		var absent=[];
        		for(var i=0;i<data.obj.length;i++){
        			categories.push(data.obj[i].time);
        			extant.push(data.obj[i].extantNum);
        			rollCall.push(data.obj[i].rollCallNum);
        			attend.push(data.obj[i].attendNum);
        			absent.push(data.obj[i].absentNum);
        		}

        		$('#column').highcharts(
    					{
    						chart : {
    							type : 'column'
    						},
    						title : {
    							text : JSON.parse(sessionStorage.userInfo).deptName+"近期考勤数据"
    						},
    						xAxis : {
    							categories : categories
    						},
    						yAxis : {
    							allowDecimals : false,
    							min : 0,
    							title : {
    								text : '人数'
    							}
    						},
    						tooltip : {
    							formatter : function() {
    								return '<b>' + this.x + '</b><br/>'
    										+ this.series.name + ': '
    										+ this.y;
    							}
    						},
    						plotOptions : {
    							column : {
    								stacking : 'normal'
    							}
    						},
    						credits : {
    							enabled : false
    						},
    						colors : [ '#66CCFF', '#FF9900', '#FF0000',
    								'#50B432' ],
    						series : [ {
    							name : '在所人数',
    							data : extant,
    							stack : 'colum1'
    						}, {
    							name : '出工人数',
    							data : rollCall,
    							stack : 'colum2'
    						}, {
    							name : '缺勤人数',
    							data : attend,
    							stack : 'colum3'
    						}, {
    							name : '实到人数',
    							data : absent,
    							stack : 'colum3'
    						} ]
    					});
        	}else{
        		bootbox.alert({
        		    message: data.message,
        		    buttons: {
        		        ok: {
        		            label: '确定'
        		        }
        		    },
        		    callback: function (result) {
        		    }
        		});
        	}
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
        	bootbox.alert({
    		    message: "近期考勤数据请求发生错误",
    		    buttons: {
    		        ok: {
    		            label: '确定'
    		        }
    		    }
    		});
        }
    });

	//最新点名未出工分析
	$.ajax({
        type: "post",
        url: utils.api_path+"main/latestAbsentData",
        dataType: "json",
        contentType: "application/json;charset=utf-8",
        data:JSON.stringify({userId:JSON.parse(sessionStorage.userInfo).id
        }),
        success: function (data) {
        	if(data.code==0){
        		var series=[];
        		for(var i=0;i<data.obj.length;i++){
        			series.push([data.obj[i].reason,data.obj[i].percent]);
        		}
        		
        		$('#pie').highcharts(
    					{
    						chart : {
    							plotBackgroundColor : null,
    							plotBorderWidth : null,
    							plotShadow : false
    						},
    						title : {
    							text : '最新点名未出工分析'
    						},
    						tooltip : {
    							headerFormat : '{series.name}<br>',
    							pointFormat : '{point.name}: <b>{point.percentage:.1f}%</b>'
    						},
    						credits : {
    							enabled : false
    						},
    						plotOptions : {
    							pie : {
    								allowPointSelect : true,
    								cursor : 'pointer',
    								dataLabels : {
    									enabled : true,
    									format : '{point.percentage:.1f} %',
    									style : {
    										color : (Highcharts.theme && Highcharts.theme.contrastTextColor)
    												|| 'black'
    									}
    								},
    								showInLegend : true
    							}
    						},
    						series : [ {
    							type : 'pie',
    							name : '未出工分析',
    							data : [ [ '零星劳作', 60 ], [ '正常探访', 20 ],
    									[ '零星探访', 10 ], [ '医院就诊', 5 ],
    									[ '所外就医', 2 ], [ '夜岗', 1 ],
    									[ '大院固定楼岗', 1 ], [ '大账员', 1 ] ]
    						} ]
    					});
        	}else{
        		bootbox.alert({
        		    message: data.message,
        		    buttons: {
        		        ok: {
        		            label: '确定'
        		        }
        		    },
        		    callback: function (result) {
        		    }
        		});
        	}
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
        	bootbox.alert({
    		    message: "最新点名未出工分析请求发生错误",
    		    buttons: {
    		        ok: {
    		            label: '确定'
    		        }
    		    }
    		});
        }
    });
});