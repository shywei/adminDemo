var userList=null;
var int;
//检索
function getUserList(){
	userList=null;
	//获取点名进行中状态信息
	var params ={
			deptId:sessionStorage.getItem("rollCallDept")
		};
	$.ajax({
		type: "post",
		url: utils.api_path+"rollCall/getRollCallStateInfo",
		dataType: "json",
		async:false,
		contentType: "application/json;charset=utf-8",
		data:JSON.stringify(params),
		success: function (data) {
			if(data.code==0){
				if(data.obj!=null){
					userList=data.obj;
					var per=utils.getPercent(userList.head.rollCallNum-userList.head.waitingRollCallNum, userList.head.rollCallNum);

					$("#extant_num").text(userList.head.extantNum);
					$("#roll_call_num").text(userList.head.rollCallNum);
					$("#waiting_roll_call_num").text(userList.head.waitingRollCallNum);
					$("#select_item_div").empty();
					$("#finish_item_div").empty();
					$("#talk_item_div").empty();
					var user_data=null;
					//图片显示
					for(var i =0;i<userList.waitingRollCall.length;i++){
						user_data=userList.waitingRollCall[i];
						$("#select_item_div").append('<div class="item width-30" data-id="'+user_data.id+'"><div class="img_show"><img src="'
								+user_data.photoUrl+"\" onerror=\"this.onerror=null;this.src='img/no-people.png'\" /></div>"
								+'<div class="img_isCheck"><i class="iconfont icon-xuanzhong"></i></div><p class="user-info text-white" title="'+user_data.userName+'">'
								+user_data.userName+'</p><p class="user-info text-white" title="'+user_data.officalNumber+'">'
								+user_data.officalNumber+'</p></div>');
					}
					user_data==userList.talkingRollCall;
					$("#talk_item_div").append('<div class="item width-90" data-id="'+user_data.id+'"><div class="img_show"><img src="'
							+user_data.photoUrl+"\" onerror=\"this.onerror=null;this.src='img/no-people.png'\" /></div>"
							+'<div class="img_isCheck"><i class="iconfont icon-xuanzhong"></i></div><p class="user-info text-white" title="'+user_data.userName+'">'
							+user_data.userName+'</p><p class="user-info text-white" title="'+user_data.officalNumber+'">'
							+user_data.officalNumber+'</p></div>');
					for(var i =0;i<userList.finishRollCall.length;i++){
						user_data=userList.finishRollCall[i];
						$("#finish_item_div").append('<div class="item width-30" data-id="'+user_data.id+'"><div class="img_show"><img src="'
								+user_data.photoUrl+"\" onerror=\"this.onerror=null;this.src='img/no-people.png'\" /></div>"
								+'<div class="img_isCheck"><i class="iconfont icon-xuanzhong"></i></div><p class="user-info text-white" title="'+user_data.userName+'">'
								+user_data.userName+'</p><p class="user-info text-white" title="'+user_data.officalNumber+'">'
								+user_data.officalNumber+'</p></div>');
					}
					$("#percent").text(per);
					$("#percent").css("width",per);
				}else{
					window.clearInterval(int);
					bootbox.alert({
						message: "点名操作已完成，返回点名管理画面。",
						buttons: {
							ok: {
								label: '确定'
							}
						},
						callback:function(){
							window.open('workRollCall.html','_self');
						}
					});
				}
			}else{
				window.clearInterval(int);
				bootbox.alert({
					message: data.message,
					buttons: {
						ok: {
							label: '确定'
						}
					},
					callback:function(){
						getUserList();
						int=setInterval("getUserList()",3000);
					}
				});
			}
		},
		error: function (XMLHttpRequest, textStatus, errorThrown) {
			//请求出错，停止刷新
			window.clearInterval(int);
			bootbox.alert({
				message: "获取点名进行中状态信息请求发生错误",
				buttons: {
					ok: {
						label: '确定'
					}
				},
				callback:function(){
					getUserList();
					int=setInterval("getUserList()",3000);
				}
			});
		}
	});
}

$(document).ready(function() {
	$("#close").click(function(){
		window.open('workRollCall.html','_self');
	});

	//初始查询
	getUserList();

	//定时刷新：3s
	int=setInterval("getUserList()",3000);
});