var userList=null;
var int;
var rollCallId;

//图片选择功能
var selectImgTake = {
	"init" : function(divId, maxSelectNumber) {
		if (maxSelectNumber == null || maxSelectNumber == "") {
			selectImgTake.initSelectEvent(divId, -1);
		} else {
			selectImgTake.initSelectEvent(divId, maxSelectNumber);
		}
	},
	"initSelectEvent" : function(divId, maxSelectNumber) {
		$("#" + divId + " .item").on(
			"click",
			function() {
				var i_display = $(this).find(
						".img_isCheck i").css("visibility");
				if (i_display == "hidden") {
					if (maxSelectNumber != -1) {
						var selectImgDivs = selectImgTake
								.getSelectImgs(divId);
						if (selectImgDivs.length >= maxSelectNumber) {
							alert("最多只能选择"
									+ maxSelectNumber
									+ "张图片");
							return;
						}
					}
					$(this).find(".img_isCheck i").css(
							"visibility", "visible");
					$(this).attr("ischecked", "true");
				} else {
					$(this).find(".img_isCheck i").css(
							"visibility", "hidden");
					$(this).removeAttr("ischecked");
				}
			});
	},
	"getSelectImgs" : function(divId) {
		var selectImgDivs = $("#" + divId + " .item[ischecked='true']");
		return selectImgDivs;
	},
	"cancelInit" : function(divId) {
		$(".img_isCheck i").css("visibility", "hidden");
		$("#" + divId + " .item").removeAttr("ischecked");
	},
	"allSelect" : function(divId) {
		$(".img_isCheck i").css("visibility", "visible");
		$("#" + divId + " .item").attr("ischecked", "true");
	}
};

//检索
function getUserList(){
	userList=null;
	//获取点名进行中状态信息
	var params ={
			deptId:sessionStorage.getItem("rollCallDept")
		};
	$.ajax({
		type: "post",
		url: utils.api_path+"rollCall/getRollCallStateInfo",
		dataType: "json",
		async:false,
		contentType: "application/json;charset=utf-8",
		data:JSON.stringify(params),
		success: function (data) {
			if(data.code==0){
				if(data.obj!=null){
					userList=data.obj;
					var per=utils.getPercent(userList.head.rollCallNum-userList.head.waitingRollCallNum, userList.head.rollCallNum);

					$("#extant_num").text(userList.head.extantNum);
					$("#roll_call_num").text(userList.head.rollCallNum);
					$("#waiting_roll_call_num").text(userList.head.waitingRollCallNum);
					$("#select_item_div").empty();
					$("#finish_item_div").empty();
					$("#talk_item_div").empty();
					var user_data=null;
					//图片显示
					for(var i =0;i<userList.waitingRollCall.length;i++){
						user_data=userList.waitingRollCall[i];
						$("#select_item_div").append('<div class="item width-30" data-id="'+user_data.id+'"><div class="img_show"><img src="'
								+user_data.photoUrl+"\" onerror=\"this.onerror=null;this.src='img/no-people.png'\" /></div>"
								+'<div class="img_isCheck"><i class="iconfont icon-xuanzhong"></i></div><p class="user-info text-white" title="'+user_data.userName+'">'
								+user_data.userName+'</p><p class="user-info text-white" title="'+user_data.officalNumber+'">'
								+user_data.officalNumber+'</p></div>');
					}
					user_data==userList.talkingRollCall;
					$("#talk_item_div").append('<div class="item width-90" data-id="'+user_data.id+'"><div class="img_show"><img src="'
							+user_data.photoUrl+"\" onerror=\"this.onerror=null;this.src='img/no-people.png'\" /></div>"
							+'<div class="img_isCheck"><i class="iconfont icon-xuanzhong"></i></div><p class="user-info text-white" title="'+user_data.userName+'">'
							+user_data.userName+'</p><p class="user-info text-white" title="'+user_data.officalNumber+'">'
							+user_data.officalNumber+'</p></div>');
					for(var i =0;i<userList.finishRollCall.length;i++){
						user_data=userList.finishRollCall[i];
						$("#finish_item_div").append('<div class="item width-30" data-id="'+user_data.id+'"><div class="img_show"><img src="'
								+user_data.photoUrl+"\" onerror=\"this.onerror=null;this.src='img/no-people.png'\" /></div>"
								+'<div class="img_isCheck"><i class="iconfont icon-xuanzhong"></i></div><p class="user-info text-white" title="'+user_data.userName+'">'
								+user_data.userName+'</p><p class="user-info text-white" title="'+user_data.officalNumber+'">'
								+user_data.officalNumber+'</p></div>');
					}
					$("#percent").text(per);
					$("#percent").css("width",per);
				}else{
					window.clearInterval(int);
					bootbox.alert({
						message: "点名操作已完成，返回点名管理画面。",
						buttons: {
							ok: {
								label: '确定'
							}
						},
						callback:function(){
							window.open('workRollCall.html','_self');
						}
					});
				}
			}else{
				window.clearInterval(int);
				bootbox.alert({
					message: data.message,
					buttons: {
						ok: {
							label: '确定'
						}
					},
					callback:function(){
						getUserList();
						int=setInterval("getUserList()",3000);
					}
				});
			}
		},
		error: function (XMLHttpRequest, textStatus, errorThrown) {
			//请求出错，停止刷新
			window.clearInterval(int);
			bootbox.alert({
				message: "获取点名进行中状态信息请求发生错误",
				buttons: {
					ok: {
						label: '确定'
					}
				},
				callback:function(){
					getUserList();
					int=setInterval("getUserList()",3000);
				}
			});
		}
	});
}

//获取选中的id
function getSelectIds(){
	var ids=[];
	if(userList.waitingRollCall.length==0){
		return ids;
	}

	selectImgTake.getSelectImgs('select_item_div').each(function(){
	    ids.push($(this).data("id"));
	  });

	return ids;
}

//检索
function getRollCallDetails(con){
	//获取当日工间点名信息列表
	var params ={
			rollCallId:rollCallId,
			pageSize:$("#per_page").val(),
		};
	$.ajax({
		type: "post",
		url: utils.api_path+"rollCall/getRollCallFinishInfoList",
		dataType: "json",
		contentType: "application/json;charset=utf-8",
		data:JSON.stringify($.extend(params,con)),
		success: function (data) {
			if(data.code==0){
				var detailList=data.obj;
				if(detailList.results.length==0){
					bootbox.alert({
						message: "没有数据!",
						buttons: {
							ok: {
								label: '确定'
							}
						}
					});
					return;
				}

				$("#extant_num").text(detailList.head.extantNum);
				$("#roll_call_num").text(detailList.head.rollCallNum);
				$("#absent_num").text(detailList.head.absentNum);

				$("#table_body").empty();
				//表格显示
				for(var i =0;i<detailList.results.length;i++){
					var rollCallData=detailList.results[i];
					$("#table_body").append('<tr><td>'+rollCallData.officalNumber+'</td><td>'+rollCallData.userName+'</td><td>'+rollCallData.rollCallStatus
							+'</td><td>'+rollCallData.memo+'</td><td>'+rollCallData.rollCallLocation+'</td><td>'+rollCallData.rollCallTime+'</td></tr>');
				}

				$('#paging').paging({
					initPageNo : detailList.page.currentPage, // 初始页码
					totalPages : detailList.page.pageCount, //总页数
					totalCount : '合计' + detailList.page.recordCount + '条数据', // 条目总数
					jump : true //是否支持跳转
				});

				$("#firstPage").click(function() {
					getRollCallList({pageNo:1});
				});
				$("#prePage").click(function() {
					getRollCallList({pageNo:detailList.page.currentPage-1});
				});
				$("#nextPage").click(function() {
					getRollCallList({pageNo:detailList.page.currentPage+1});
				});
				$("#lastPage").click(function() {
					getRollCallList({pageNo:detailList.page.pageCount});
				});
				$("#jumpBtn").click(function() {
					getRollCallList({pageNo:$("#jumpText").val()});
				});
				$("#pageSelect li").click(function() {
					getRollCallList({pageNo:$(this).text()});
				});
			}else{
				bootbox.alert({
					message: data.message,
					buttons: {
						ok: {
							label: '确定'
						}
					},
					callback:function(){
						window.open('workRollCall.html','_self');
					}
				});
			}
		},
		error: function (XMLHttpRequest, textStatus, errorThrown) {
			bootbox.alert({
				message: "获取当日工间点名信息列表请求发生错误",
				buttons: {
					ok: {
						label: '确定'
					}
				},
				callback:function(){
					window.open('workRollCall.html','_self');
				}
			});
		}
	});
}

$(document).ready(function() {
	//完成点名
	$("#finish").click(function(){
		window.clearInterval(int);
		$.ajax({
	        type: "post",
	        url: utils.api_path+"rollCall/finishRollCall",
	        dataType: "json",
	        contentType: "application/json;charset=utf-8",
	        data:JSON.stringify({deptId:sessionStorage.getItem("rollCallDept")
	        }),
	        success: function (data) {
	        	if(data.code==0){
	        		rollCallId=data.obj;
	        		$('.processing').hide();
	        		$('.result').show();
	        		getRollCallDetails({pageNo:1});
	        	}else{
	        		bootbox.alert({
	        		    message: data.message,
	        		    buttons: {
	        		        ok: {
	        		            label: '确定'
	        		        }
	        		    },
	    				callback:function(){
	    					getUserList();
	    					int=setInterval("getUserList()",3000);
	    				}
	        		});
	        	}
	        },
	        error: function (XMLHttpRequest, textStatus, errorThrown) {
	        	bootbox.alert({
        		    message: "完成点名请求发生错误！",
        		    buttons: {
        		        ok: {
        		            label: '确定'
        		        }
        		    },
    				callback:function(){
    					getUserList();
    					int=setInterval("getUserList()",3000);
    				}
        		});
	        }
	    });
	});

	//暂停点名
	$("#stop").click(function(){
		window.clearInterval(int);
		$.ajax({
	        type: "post",
	        url: utils.api_path+"rollCall/pauseRollCall",
	        dataType: "json",
	        contentType: "application/json;charset=utf-8",
	        data:JSON.stringify({deptId:sessionStorage.getItem("rollCallDept")
	        }),
	        success: function (data) {
	        	if(data.code==0){
	        		getUserList();
	        		$("#change").show();
	        		$("#finish").attr("disabled",true);
	        		$("#stop").hide();
	        		$("#continue").show();
	        		$("#cancel").attr("disabled",true);
	        		selectImgTake.init('select_item_div', -1);
	        	}else{
	        		bootbox.alert({
	        		    message: data.message,
	        		    buttons: {
	        		        ok: {
	        		            label: '确定'
	        		        }
	        		    },
	    				callback:function(){
	    					getUserList();
	    					int=setInterval("getUserList()",3000);
	    				}
	        		});
	        	}
	        },
	        error: function (XMLHttpRequest, textStatus, errorThrown) {
	        	bootbox.alert({
        		    message: "获取单位ID名称数据请求发生错误！",
        		    buttons: {
        		        ok: {
        		            label: '确定'
        		        }
        		    },
    				callback:function(){
    					getUserList();
    					int=setInterval("getUserList()",3000);
    				}
        		});
	        }
	    });
	});

	//继续点名
	$("#continue").click(function(){
		$("#select_item_div .item").off("click");
		selectImgTake.cancelInit('select_item_div');
		$("#change").hide();
		$("#finish").removeAttr("disabled");
		$("#stop").show();
		$("#continue").hide();
		$("#cancel").removeAttr("disabled");
		getUserList();
		int=setInterval("getUserList()",3000);
	});

	//确认
	$("#confirm").click(function(){
		window.open('workRollCall.html','_self');
	});

	//取消点名
	$("#cancel").click(function(){
		window.clearInterval(int);
		$.ajax({
	        type: "post",
	        url: utils.api_path+"rollCall/cancelRollCall",
	        dataType: "json",
	        contentType: "application/json;charset=utf-8",
	        data:JSON.stringify({deptId:sessionStorage.getItem("rollCallDept")
	        }),
	        success: function (data) {
	        	if(data.code==0){
	        		window.open('workRollCall.html','_self');
	        	}else{
	        		bootbox.alert({
	        		    message: data.message,
	        		    buttons: {
	        		        ok: {
	        		            label: '确定'
	        		        }
	        		    },
	    				callback:function(){
	    					getUserList();
	    					int=setInterval("getUserList()",3000);
	    				}
	        		});
	        	}
	        },
	        error: function (XMLHttpRequest, textStatus, errorThrown) {
	        	bootbox.alert({
        		    message: "取消点名请求发生错误！",
        		    buttons: {
        		        ok: {
        		            label: '确定'
        		        }
        		    },
    				callback:function(){
    					getUserList();
    					int=setInterval("getUserList()",3000);
    				}
        		});
	        }
	    });
	});

	//人员去向
	$("#change").click(function(){
		if(getSelectIds().length==0){
			bootbox.alert({
    		    message: "未选中任何人员！",
    		    buttons: {
    		        ok: {
    		            label: '确定'
    		        }
    		    }
    		});
			return false;
		}
		var data =JSON.parse(sessionStorage.getItem("rollCallUserState"));
		var options=[{
            text: '',
            value: '',
        }];
		for(var i=0;i<data.values.length;i++){
			options.push({value:data.values[i].fieldValue,text:data.values[i].fieldValueDisplay,});
		}
		bootbox.prompt({
		    title: "修改人员去向",
		    inputType: 'select',
		    inputOptions: options,
		    buttons: {
		        cancel: {
		            label: '取消'
		        },
		        confirm: {
		            label: '确定'
		        }
		    },
		    callback: function (result) {
		    	if(result==''){
		        	bootbox.alert({
	        		    message: "未选择去向！",
	        		    buttons: {
	        		        ok: {
	        		            label: '确定'
	        		        }
	        		    }
	        		});
		        }else if(result!=null){
		        	$.ajax({
				        type: "post",
				        url: utils.api_path+"rollCall/changeUserState",
				        dataType: "json",
				        contentType: "application/json;charset=utf-8",
				        data:JSON.stringify({deptId:sessionStorage.getItem("rollCallDept"),
				        	userIds:getSelectIds().join(","),
				        	userStateDisplayValue :result}),
				        success: function (data) {
				        	if(data.code==0){
				        		//修改人员去向后重新检索
				        		getUserList();
				        		selectImgTake.init('select_item_div', -1);
				        	}else{
				        		bootbox.alert({
				        		    message: data.message,
				        		    buttons: {
				        		        ok: {
				        		            label: '确定'
				        		        }
				        		    }
				        		});
				        	}
				        },
				        error: function (XMLHttpRequest, textStatus, errorThrown) {
				        	bootbox.alert({
			        		    message: "修改人员去向请求发生错误！",
			        		    buttons: {
			        		        ok: {
			        		            label: '确定'
			        		        }
			        		    }
			        		});
				        }
				    });
		        }
		    }
		});
	});

	utils.setOptions("per_page","pageSize");
	//改变每页件数，触发查询
	$("#per_page").change(function() {
		getRollCallDetails({pageNo:1});
	});

	//初始查询
	getUserList();

	//定时刷新：3s
	int=setInterval("getUserList()",3000);
});