utils.getMenu("点名管理","工间点名");
var rollCallList=null;

//跳转到详情画面
function goDetail(id){
	for(var i =0;i<rollCallList.results.length;i++){
		if(rollCallList.results[i].id==id){
			if(rollCallList.results[i].state==0){
				sessionStorage.setItem("rollCallId",id);
				//点名详情
				window.open('rollCallDetail.html','_self');
			}else{
				$.ajax({
					type: "post",
					url: utils.api_path+"rollCall/beginRollCall",
					dataType: "json",
					contentType: "application/json;charset=utf-8",
					data:JSON.stringify({loginUserId:JSON.parse(sessionStorage.userInfo).id,targetDeptId:rollCallList.results[i].deptId}),
					success: function (data) {
						if(data.code==0){
							sessionStorage.setItem("rollCallDept",data.obj.deptId);
							if(data.obj.type=="操作"){
								//操作模式
								window.open('rollCall.html','_self');
							}else{
								//查看模式
								window.open('rollCallView.html','_self');
							}

						}else{
							bootbox.alert({
								message: data.message,
								buttons: {
									ok: {
										label: '确定'
									}
								}
							});
						}
					},
					error: function (XMLHttpRequest, textStatus, errorThrown) {
						bootbox.alert({
							message: "获取当日工间点名信息列表请求发生错误",
							buttons: {
								ok: {
									label: '确定'
								}
							}
						});
					}
				});
			}
		}
	}
}

//检索
function getRollCallList(con){
	rollCallList=null;
	sessionStorage.removeItem("rollCallList");
	//获取当日工间点名信息列表
	var params ={
			currentLoginUserId:JSON.parse(sessionStorage.userInfo).id,
			pageSize:$("#per_page").val(),
		};
	$.ajax({
		type: "post",
		url: utils.api_path+"rollCall/getCurrentRollCallList",
		dataType: "json",
		contentType: "application/json;charset=utf-8",
		data:JSON.stringify($.extend(params,con)),
		success: function (data) {
			if(data.code==0){
				rollCallList=data.obj;
				sessionStorage.setItem("rollCallList",JSON.stringify(rollCallList));
				if(rollCallList.results.length==0){
					$("#data_area").hide();
					$("#no_data").show();
					return;
				}
				$("#data_area").show();
				$("#no_data").hide();

				$("#table_body").empty();
				//表格显示
				for(var i =0;i<rollCallList.results.length;i++){
					var rollCallData=rollCallList.results[i];
					$("#table_body").append('<tr><td>'+rollCallData.detpName+'</td><td>'+rollCallData.startTime+'</td><td>'+utils.getOptionName("rollCallState",rollCallData.state)
							+'</td><td>'+rollCallData.registeredNum+'</td><td>'+rollCallData.extantNum+'</td><td>'+rollCallData.rollCallNum+'</td><td>'+rollCallData.attendNum
							+'</td><td>'+rollCallData.absentNum+'</td><td><a class="text-primary" href="#" onclick="goDetail('+rollCallData.id+')">'+"详情"+'</a></td></tr>');
				}

				$('#paging').paging({
					initPageNo : rollCallList.page.currentPage, // 初始页码
					totalPages : rollCallList.page.pageCount, //总页数
					totalCount : '合计' + rollCallList.page.recordCount + '条数据', // 条目总数
					jump : true //是否支持跳转
				});

				$("#firstPage").click(function() {
					getRollCallList({pageNo:1});
				});
				$("#prePage").click(function() {
					getRollCallList({pageNo:rollCallList.page.currentPage-1});
				});
				$("#nextPage").click(function() {
					getRollCallList({pageNo:rollCallList.page.currentPage+1});
				});
				$("#lastPage").click(function() {
					getRollCallList({pageNo:rollCallList.page.pageCount});
				});
				$("#jumpBtn").click(function() {
					getRollCallList({pageNo:$("#jumpText").val()});
				});
				$("#pageSelect li").click(function() {
					getRollCallList({pageNo:$(this).text()});
				});
			}else{
				$("#data_area").hide();
				$("#no_data").hide();
				bootbox.alert({
					message: data.message,
					buttons: {
						ok: {
							label: '确定'
						}
					}
				});
			}
		},
		error: function (XMLHttpRequest, textStatus, errorThrown) {
			$("#data_area").hide();
			$("#no_data").hide();
			bootbox.alert({
				message: "获取当日工间点名信息列表请求发生错误",
				buttons: {
					ok: {
						label: '确定'
					}
				}
			});
		}
	});
}

//开始点名
function beginRollCall(){
	$.ajax({
		type: "post",
		url: utils.api_path+"rollCall/beginRollCall",
		dataType: "json",
		contentType: "application/json;charset=utf-8",
		data:JSON.stringify({loginUserId:JSON.parse(sessionStorage.userInfo).id}),
		success: function (data) {
			if(data.code==0){
				sessionStorage.setItem("rollCallDept",data.obj.deptId);
				window.open('rollCall.html','_self');
			}else{
				bootbox.alert({
					message: data.message,
					buttons: {
						ok: {
							label: '确定'
						}
					}
				});
			}
		},
		error: function (XMLHttpRequest, textStatus, errorThrown) {
			bootbox.alert({
				message: "获取当日工间点名信息列表请求发生错误",
				buttons: {
					ok: {
						label: '确定'
					}
				}
			});
		}
	});
}

$(document).ready(function() {
	//开始点名
	$("#start").click(function() {
		beginRollCall();
	});

	//改变每页件数，触发查询
	$("#per_page").change(function() {
		getRollCallList({pageNo:1});
	});

	utils.setOptions("per_page","pageSize");

	sessionStorage.removeItem("rollCallDept");
	sessionStorage.removeItem("rollCallId");
	//初期查询
	getRollCallList({pageNo:1});
});
