var display_mode =0;//显示模式0图片，1表格
var userList=null;
utils.getMenu("戒毒人员","人员管理");
utils.getDept(0);

//图片选择功能
var selectImgTake = {
	"init" : function(divId, maxSelectNumber) {
		if (maxSelectNumber == null || maxSelectNumber == "") {
			selectImgTake.initSelectEvent(divId, -1);
		} else {
			selectImgTake.initSelectEvent(divId, maxSelectNumber);
		}
	},
	"initSelectEvent" : function(divId, maxSelectNumber) {
		$("#" + divId + " .item").on(
			"click",
			function() {
				var i_display = $(this).find(
						".img_isCheck i").css("visibility");
				if (i_display == "hidden") {
					if (maxSelectNumber != -1) {
						var selectImgDivs = selectImgTake
								.getSelectImgs(divId);
						if (selectImgDivs.length >= maxSelectNumber) {
							alert("最多只能选择"
									+ maxSelectNumber
									+ "张图片");
							return;
						}
					}
					$(this).find(".img_isCheck i").css(
							"visibility", "visible");
					$(this).attr("ischecked", "true");
				} else {
					$(this).find(".img_isCheck i").css(
							"visibility", "hidden");
					$(this).removeAttr("ischecked");
				}
			});
	},
	"getSelectImgs" : function(divId) {
		var selectImgDivs = $("#" + divId + " .item[ischecked='true']");
		return selectImgDivs;
	},
	"cancelInit" : function(divId) {
		$(".img_isCheck i").css("visibility", "hidden");
		$("#" + divId + " .item").removeAttr("ischecked");
	},
	"allSelect" : function(divId) {
		$(".img_isCheck i").css("visibility", "visible");
		$("#" + divId + " .item").attr("ischecked", "true");
	}
};

//录入掌静脉
function LoadPalm() {
    //debugger;
    try {
        var agent=navigator.userAgent.toLowerCase();
        //console.log(agent);
        //console.log(navigator.platform);
//        console.log(getOs());

        //if((agent.indexOf("win64")>=0||agent.indexOf("wow64")>=0)&& navigator.platform ==='Win32'){
        //    alert('请使用64位的浏览器');
        //}else{
            if(getOs()==="MSIE"){
                var objectX = document.getElementById("myobj");
            }
            else{
                var objectX = document.getElementById("myotherobj");
            }
            var init = objectX.Pvs_InitCtrl();
            if (init.toString() === "1") {
                var load = objectX.Pvs_EnrollSingleHand();
                if (load.toString() === "1") {
                    objectX.Pvs_CloseSensor();
                    var veinData = objectX.Pvs_GetEnrollVeinData();
                    document.getElementById("veinData").value = veinData.toString();
                }
                else {
                    objectX.Pvs_CloseSensor();
                }
            }
            else {
                alert('请先安装驱动和传感器！');
                objectX.Pvs_CloseSensor();
            }
        //}
    }
    catch (e) {
        alert(e.message);
    }
}

function getOs()
{
	var OsObject = "";
	if(navigator.userAgent.indexOf("MSIE")>0) {
		 return "MSIE";
	}
	if(isFirefox=navigator.userAgent.indexOf("Firefox")>0){
		 return "Firefox";
	}
	if(isSafari=navigator.userAgent.indexOf("Safari")>0) {
		 return "Safari";
	}
	if(isCamino=navigator.userAgent.indexOf("Camino")>0){
		 return "Camino";
	}
	if(isMozilla=navigator.userAgent.indexOf("Gecko/")>0){
		 return "Gecko";
	}
}

//检索
function getUserList(con){
	userList=null;
	//获取人员列表
	var params ={
			userName:$("#user_name").val(),
			officalNumber:$("#offical_number").val(),
			userState :$("#user_state").val(),
			createTime :$("#create_time").val(),
			deptId:$("#dept_id").val(),
			confirmChangeDept:0,
			pageSize:$("#per_page").val(),
		};
	$.ajax({
		type: "post",
		url: utils.api_path+"user/getUserList",
		dataType: "json",
		contentType: "application/json;charset=utf-8",
		data:JSON.stringify($.extend(params,con)),
		success: function (data) {
			if(data.code==0){
				userList=data.obj;
				if(userList.results.length==0){
					$("#data_area").hide();
					$("#no_data").show();
					return;
				}
				$("#table_select_all").prop('checked',false);
				$("#data_area").show();
				$("#no_data").hide();
				if(display_mode==0){
					$("#select_item_div").empty();
					//图片显示
					for(var i =0;i<userList.results.length;i++){
						var user_data=userList.results[i];
						$("#select_item_div").append('<div class="item width-10" data-id="'+user_data.id+'"><div class="img_show"><img src="'
								+user_data.photoUrl+"\" onerror=\"this.onerror=null;this.src='img/no-people.png'\" /></div>"
								+'<div class="img_isCheck"><i class="iconfont icon-xuanzhong"></i></div><p class="user-info" title="'+user_data.userName+'">'
								+user_data.userName+'</p><p class="user-info" title="'+user_data.officalNumber+'">'
								+user_data.officalNumber+'</p><p class="user-info" title="'+utils.getDeptName(user_data.deptId)+'">'+utils.getDeptName(user_data.deptId)+'</p></div>');
					}
					selectImgTake.init('select_item_div', -1);
				}else{
					$("#table_body").empty();
					//表格显示
					for(var i =0;i<userList.results.length;i++){
						var user_data=userList.results[i];
						$("#table_body").append('<tr><td><input type="checkbox" data-id="'+user_data.id+'"></td><td>'+user_data.userName+'</td><td>'+user_data.officalNumber
								+'</td><td>'+utils.getOptionName("userState", user_data.userState)+'</td><td>'+user_data.createTime+'</td><td>'+utils.getDeptName(user_data.deptId)+'</td><td>'+user_data.updateTime
								+'</td><td>'+utils.getOptionName("hasMetacarpalVein", user_data.hasMetacarpalVein)+'</td></tr>');
					}
				}
				$('#paging').paging({
					initPageNo : userList.page.currentPage, // 初始页码
					totalPages : userList.page.pageCount, //总页数
					totalCount : '合计' + userList.page.recordCount + '条数据', // 条目总数
					jump : true //是否支持跳转
				});

				$("#firstPage").click(function() {
					getUserList({pageNo:1});
				});
				$("#prePage").click(function() {
					getUserList({pageNo:userList.page.currentPage-1});
				});
				$("#nextPage").click(function() {
					getUserList({pageNo:userList.page.currentPage+1});
				});
				$("#lastPage").click(function() {
					getUserList({pageNo:userList.page.pageCount});
				});
				$("#jumpBtn").click(function() {
					getUserList({pageNo:$("#jumpText").val()});
				});
				$("#pageSelect li").click(function() {
					getUserList({pageNo:$(this).text()});
				});
			}else{
				$("#data_area").hide();
				$("#no_data").hide();
				bootbox.alert({
					message: data.message,
					buttons: {
						ok: {
							label: '确定'
						}
					}
				});
			}
		},
		error: function (XMLHttpRequest, textStatus, errorThrown) {
			$("#data_area").hide();
			$("#no_data").hide();
			bootbox.alert({
				message: "获取人员列表请求发生错误",
				buttons: {
					ok: {
						label: '确定'
					}
				}
			});
		}
	});
}

//获取选中的id
function getSelectIds(){
	var ids=[];
	if(userList.results.length==0){
		return ids;
	}
	if(display_mode==0){
		selectImgTake.getSelectImgs('select_item_div').each(function(){
		    ids.push($(this).data("id"));
		  });
	}else{
		$("#table_body :checked").each(function(){
		    ids.push($(this).data("id"));
		  });
	}
	return ids;
}

//获取选中的用户信息
function getSelectUser(){
	var ids=getSelectIds();
	for(var i=0;i<userList.results.length;i++){
		if(userList.results[i].id==ids[0]){
			return userList.results[i];
		}
	}
}

$(document).ready(function() {
	//图片取消选择
	$("#cancel").click(function() {
		selectImgTake.cancelInit('select_item_div');
	});

	//图片全选
	$("#select_all").click(function() {
		selectImgTake.allSelect('select_item_div');
	});

	//表格全选
	$("#table_select_all").click(function() {
		if($("#table_select_all").prop('checked')){
			$("#table_body :checkbox").prop("checked",true);
		}else{
			$("#table_body :checkbox").prop("checked",false);
		}

	});

	//表格显示
	$("#display_table").click(function() {
		display_mode=1;
		$("#per_page").val(10);
		getUserList({pageNo:1});
	});

	//图片列表显示
	$("#display_pic").click(function() {
		display_mode=0;
		$("#per_page").val(10);
		getUserList({pageNo:1});
	});

	//登记人员
	$("#register").click(function() {
		//打开模态窗前，清空输入值和错误提示
		var file = $("#upload_image") ;
		file.after(file.clone().val(""));
		file.remove();
		$("#upload_image").on("change", function(){
		    var files = !!this.files ? this.files : [];

		    if (!files.length || !window.FileReader) return;

		    if (/^image/.test( files[0].type)){

		        var reader = new FileReader();

		        reader.readAsDataURL(files[0]);

		        reader.onloadend = function(){
		        	$("#upload_preview").css("background-image", "url("+this.result+")");
		        };
		    }
		});
		$("#upload_preview").css("background-image", "");
		$("#photo_url").val("");
		$("#veinData").val("");
		$("#input_user_name").val("");
		$("#input_offical_number").val("");
		$("#input_gender").val("");
		$("#input_dept_id").val("");
		$("#input_dept_id").removeAttr("disabled");
		$("#input_create_time").val("");
		$("#display_create_time").val("");
		$("#input_height").val("");
		$("#input_nationalities").val("");
		$("#input_marital_status").val("");
		$("#input_card_type").val("");
		$("#input_card_num").val("");
		$("#input_contact").val("");
		$("#input_contact_num").val("");
		$("#input_home_address").val("");
		$("#input_residence_adress").val("");
		$("label.text-error").hide();
		$(".text-error").removeClass("text-error");
		$("#myModalLabel").text("登记人员");

		$("#modal_edit").modal('show');
	});

	//修改人员信息
	$("#edit").click(function() {
		if(getSelectIds().length!=1){
			bootbox.alert({
    		    message: "必须且只能选择一条数据！",
    		    buttons: {
    		        ok: {
    		            label: '确定'
    		        }
    		    }
    		});
			return false;
		}
		var data =getSelectUser();

		//打开模态窗前，清空错误提示、填入既存信息
		var file = $("#upload_image") ;
		file.after(file.clone().val(""));
		file.remove();
		$("#upload_image").on("change", function(){
		    var files = !!this.files ? this.files : [];

		    if (!files.length || !window.FileReader) return;

		    if (/^image/.test( files[0].type)){

		        var reader = new FileReader();

		        reader.readAsDataURL(files[0]);

		        reader.onloadend = function(){
		        	$("#upload_preview").css("background-image", "url("+this.result+")");
		        };
		    }
		});
		$("label.text-error").hide();
		$(".text-error").removeClass("text-error");
		$("#upload_preview").css("background-image", "url("+data.photoUrl+")");
		$("#photo_url").val(data.photoUrl);
		$("#veinData").val("");
		$("#input_user_name").val(data.userName);
		$("#input_offical_number").val(data.officalNumber);
		$("#input_gender").val(data.gender);
		$("#input_dept_id").val(data.deptId);
		$("#input_dept_id").attr("disabled",true);
		$("#input_create_time").val(data.createTime);
		$("#display_create_time").val(data.createTime);
		$("#input_height").val(data.height);
		$("#input_nationalities").val(data.nationalities);
		$("#input_marital_status").val(data.maritalStatus);
		$("#input_card_type").val(data.cardType);
		$("#input_card_num").val(data.cardNum);
		$("#input_contact").val(data.contact);
		$("#input_contact_num").val(data.contactNum);
		$("#input_home_address").val(data.homeAddress);
		$("#input_residence_adress").val(data.residenceAdress);
		$("#myModalLabel").text("修改人员信息");

		$("#modal_edit").modal('show');

	});

	//修改人员状态
	$("#edit_status").click(function() {
		if(getSelectIds().length==0){
			bootbox.alert({
    		    message: "未选中任何人员！",
    		    buttons: {
    		        ok: {
    		            label: '确定'
    		        }
    		    }
    		});
			return false;
		}
		var data =JSON.parse(sessionStorage.getItem("userState"));
		var options=[{
            text: '',
            value: '',
        }];
		for(var i=0;i<data.values.length;i++){
			options.push({value:data.values[i].fieldValue,text:data.values[i].fieldValueDisplay,});
		}
		bootbox.prompt({
		    title: "修改人员状态",
		    inputType: 'select',
		    inputOptions: options,
		    buttons: {
		        cancel: {
		            label: '取消'
		        },
		        confirm: {
		            label: '确定'
		        }
		    },
		    callback: function (result) {
		    	if(result==''){
		        	bootbox.alert({
	        		    message: "未选择状态！",
	        		    buttons: {
	        		        ok: {
	        		            label: '确定'
	        		        }
	        		    }
	        		});
		        }else if(result!=null){
		        	$.ajax({
				        type: "post",
				        url: utils.api_path+"user/modifyUserState",
				        dataType: "json",
				        contentType: "application/json;charset=utf-8",
				        data:JSON.stringify({userIds:getSelectIds().join(","),userState:result}),
				        success: function (data) {
				        	if(data.code==0){
				        		//修改人员状态后重新检索
				        		getUserList({pageNo:1});
				        	}else{
				        		bootbox.alert({
				        		    message: data.message,
				        		    buttons: {
				        		        ok: {
				        		            label: '确定'
				        		        }
				        		    }
				        		});
				        	}
				        },
				        error: function (XMLHttpRequest, textStatus, errorThrown) {
				        	bootbox.alert({
			        		    message: "修改人员状态请求发生错误！",
			        		    buttons: {
			        		        ok: {
			        		            label: '确定'
			        		        }
			        		    }
			        		});
				        }
				    });
		        }
		    }
		});
	});

	//释放人员按钮
	$("#delete").click(function(){
		if(getSelectIds().length==0){
			bootbox.alert({
    		    message: "未选中任何人员！",
    		    buttons: {
    		        ok: {
    		            label: '确定'
    		        }
    		    }
    		});
			return false;
		}

		bootbox.confirm({
		    title: "释放人员",
		    message: "选定人员将离所不在册，请确认",
		    buttons: {
		        cancel: {
		            label: '取消'
		        },
		        confirm: {
		            label: '确定'
		        }
		    },
		    callback: function (result) {
		        if(result){
		        	$.ajax({
				        type: "post",
				        url: utils.api_path+"user/deleteUser",
				        dataType: "json",
				        contentType: "application/json;charset=utf-8",
				        data:JSON.stringify({userIds:getSelectIds().join(",")}),
				        success: function (data) {
				        	if(data.code==0){
				        		//删除成功后重新检索
				        		getUserList({pageNo:1});
				        	}else{
				        		bootbox.alert({
				        		    message: data.message,
				        		    buttons: {
				        		        ok: {
				        		            label: '确定'
				        		        }
				        		    }
				        		});
				        	}
				        },
				        error: function (XMLHttpRequest, textStatus, errorThrown) {
				        	bootbox.alert({
			        		    message: "删除用户请求发生错误！",
			        		    buttons: {
			        		        ok: {
			        		            label: '确定'
			        		        }
			        		    }
			        		});
				        }
				    });
		        }
		    }
		});
	});

	//日历控件初始化
	$('.form_date').datetimepicker({
		language:  'zh-CN',
		weekStart: 1,
		todayBtn:  1,
		autoclose: 1,
		todayHighlight: 1,
		startView: 2,
		minView: 2,
		forceParse: 0
	});

	//选择照片，预览
	$("#upload_image").on("change", function(){
	    var files = !!this.files ? this.files : [];

	    if (!files.length || !window.FileReader) return;

	    if (/^image/.test( files[0].type)){

	        var reader = new FileReader();

	        reader.readAsDataURL(files[0]);

	        reader.onloadend = function(){
	        	$("#upload_preview").css("background-image", "url("+this.result+")");
	        };
	    }
	});

	//查询表单
	$("#search_form").validate({
		rules : {
			user_name : {
				maxlength : 10
			},
			offical_number : {
				maxlength : 10
			}
		},
		errorClass:"text-error",
		messages : {
			user_name : {
				maxlength : "用户名最长十位"
			},
			offical_number : {
				maxlength : "所编号最长十位"
			}
		},
		submitHandler : function(form) {
			getUserList({pageNo:1});
		}
	});

	//编辑模态窗表单
	$("#edit_form").validate({
		rules : {
			input_user_name : {
				required : true
			},
			input_offical_number : {
				required : true
			},
			input_gender : {
				required : true
			},
			input_dept_id : {
				required : true
			},
			input_create_time : {
				required : true
			}
		},
		errorClass:"text-error",
		onclick:false,
		onfocusout:false,
		onkeyup:false,
		messages : {
			input_user_name : {
				required : "请输入姓名"
			},
			input_offical_number : {
				required : "请输入所编号"
			},
			input_gender : {
				required : "请选择性别"
			},
			input_dept_id : {
				required : "请选择单位"
			},
			input_create_time : {
				required : "请输入入所时间"
			}
		},
		success: function(label) {
		    console.log('success');
		},
		submitHandler : function(form) {
			var files = !!$("#upload_image")[0].files ? $("#upload_image")[0].files : [];
			var process_flag=true;
		    if (files.length!=0){
		    	//上传照片
		    	var fileObj = files[0]; // 获取文件对象
	            // FormData 对象
	            var form = new FormData();
	            form.append("officalNumber", $("#input_offical_number").val());
	            form.append("file", fileObj);
	            $.ajax({
			        type: "post",
			        async:false,
			        url: utils.api_path+"user/uploadPhoto",
			        dataType: "json",
			        cache: false,
			        processData: false,
			        contentType: false,
			        data:form,
			        success: function (data) {
			        	if(data.code==0){
			        		$("#photo_url").val(data.obj);
			        	}else{
			        		process_flag=false;
			        		bootbox.alert({
			        		    message: data.message,
			        		    buttons: {
			        		        ok: {
			        		            label: '确定'
			        		        }
			        		    }
			        		});
			        	}
			        },
			        error: function (XMLHttpRequest, textStatus, errorThrown) {
			        	process_flag=false;
			        	bootbox.alert({
		        		    message: "上传照片请求发生错误！",
		        		    buttons: {
		        		        ok: {
		        		            label: '确定'
		        		        }
		        		    }
		        		});
			        }
			    });
		    }
		    if(process_flag){
		    	var params={
		    			officalNumber:$("#input_offical_number").val(),
		    			userName:$("#input_user_name").val(),
		    			gender:$("#input_gender").val(),
		    			height:$("#input_height").val(),
		    			deptId:$("#input_dept_id").val(),
		    			createTime:$("#input_create_time").val(),
		    			nationalities:$("#input_nationalities").val(),
		    			maritalStatus:$("#input_marital_status").val(),
		    			cardType:$("#input_card_type").val(),
		    			cardNum:$("#input_card_num").val(),
		    			contact:$("#input_contact").val(),
		    			contactNum:$("#input_contact_num").val(),
		    			homeAddress:$("#input_home_address").val(),
		    			residenceAdress:$("#input_residence_adress").val(),
		    			metacarpalVein:$("#veinData").val(),
		    			photoUrl:$("#photo_url").val()
		    	};
		    	if($("#myModalLabel").text()=="登记人员"){
		    		$.ajax({
				        type: "post",
				        url: utils.api_path+"user/addUser",
				        dataType: "json",
				        contentType: "application/json;charset=utf-8",
				        data:JSON.stringify(params),
				        success: function (data) {
				        	if(data.code==0){
				        		$("#modal_edit").modal('hide');
				        		//重新检索
				        		getUserList({pageNo:1});
				        	}else{
				        		bootbox.alert({
				        		    message: data.message,
				        		    buttons: {
				        		        ok: {
				        		            label: '确定'
				        		        }
				        		    }
				        		});
				        	}
				        },
				        error: function (XMLHttpRequest, textStatus, errorThrown) {
				        	bootbox.alert({
			        		    message: "登记人员请求发生错误！",
			        		    buttons: {
			        		        ok: {
			        		            label: '确定'
			        		        }
			        		    }
			        		});
				        }
				    });
		    	}else{
		    		$.ajax({
				        type: "post",
				        url: utils.api_path+"user/modifyUser",
				        dataType: "json",
				        contentType: "application/json;charset=utf-8",
				        data:JSON.stringify($.extend(params,{id:getSelectUser().id})),
				        success: function (data) {
				        	if(data.code==0){
				        		$("#modal_edit").modal('hide');
				        		//修改人员状态后重新检索
				        		getUserList({pageNo:1});
				        	}else{
				        		bootbox.alert({
				        		    message: data.message,
				        		    buttons: {
				        		        ok: {
				        		            label: '确定'
				        		        }
				        		    }
				        		});
				        	}
				        },
				        error: function (XMLHttpRequest, textStatus, errorThrown) {
				        	bootbox.alert({
			        		    message: "修改人员信息请求发生错误！",
			        		    buttons: {
			        		        ok: {
			        		            label: '确定'
			        		        }
			        		    }
			        		});
				        }
				    });
		    	}
		    }

		}
	});

	//改变每页件数，触发查询
	$("#per_page").change(function() {
		getUserList({pageNo:1});
	});

	//下拉列表选项
	utils.setOptions("user_state","userState");
	utils.setOptions("input_gender","gender");
	utils.setOptions("input_marital_status","maritalStatus");
	utils.setOptions("input_card_type","cardType");
	utils.setOptions("per_page","pageSize");
	utils.setDeptOptions("dept_id");
	utils.setDeptOptions("input_dept_id");

	//初期查询
	getUserList({pageNo:1});
});