var roleList=null;
utils.getMenu("系统管理","系统角色管理");

//检索
function getRoleList(con){
	roleList=null;
	//获取角色列表
	var params ={
			pageSize:$("#per_page").val(),
		};
	$.ajax({
		type: "post",
		url: utils.api_path+"authority/getRoleList",
		dataType: "json",
		contentType: "application/json;charset=utf-8",
		data:JSON.stringify($.extend(params,con)),
		success: function (data) {
			if(data.code==0){
				roleList=data.obj;
				if(roleList.length==0){
					$("#data_area").hide();
					$("#no_data").show();
					return;
				}
				$("#table_select_all").prop('checked',false);
				$("#data_area").show();
				$("#no_data").hide();

				$("#table_body").empty();
				//表格显示
				for(var i =0;i<roleList.results.length;i++){
					var role_data=roleList.results[i];
					$("#table_body").append('<tr><td><input type="checkbox" data-id="'+role_data.roleId+'"></td><td>'+role_data.roleName+'</td><td>'+role_data.systemUserCount+'</td><td>'
							+role_data.createTime+'</td><td>'+role_data.updateTime+'</td><td>'+role_data.memo+'</td></tr>');
				}

				$('#paging').paging({
					initPageNo : roleList.page.currentPage, // 初始页码
					totalPages : roleList.page.pageCount, //总页数
					totalCount : '合计' + roleList.page.recordCount + '条数据', // 条目总数
					jump : true //是否支持跳转
				});

				$("#firstPage").click(function() {
					getRoleList({pageNo:1});
				});
				$("#prePage").click(function() {
					getRoleList({pageNo:roleList.page.currentPage-1});
				});
				$("#nextPage").click(function() {
					getRoleList({pageNo:roleList.page.currentPage+1});
				});
				$("#lastPage").click(function() {
					getRoleList({pageNo:roleList.page.pageCount});
				});
				$("#jumpBtn").click(function() {
					getRoleList({pageNo:$("#jumpText").val()});
				});
				$("#pageSelect li").click(function() {
					getRoleList({pageNo:$(this).text()});
				});
			}else{
				$("#data_area").hide();
				$("#no_data").hide();
				bootbox.alert({
					message: data.message,
					buttons: {
						ok: {
							label: '确定'
						}
					}
				});
			}
		},
		error: function (XMLHttpRequest, textStatus, errorThrown) {
			$("#data_area").hide();
			$("#no_data").hide();
			bootbox.alert({
				message: "查询角色列表请求发生错误",
				buttons: {
					ok: {
						label: '确定'
					}
				}
			});
		}
	});
}

//获取选中的id
function getSelectIds(){
	var ids=[];
	if(roleList.results.length==0){
		return ids;
	}
	$("#table_body :checked").each(function(){
	    ids.push($(this).data("id"));
	  });
	return ids;
}

//获取选中的角色信息
function getSelectRole(){
	var ids=getSelectIds();
	for(var i=0;i<roleList.results.length;i++){
		if(roleList.results[i].roleId==ids[0]){
			return roleList.results[i];
		}
	}
}

$(document).ready(function() {
	//表格全选
	$("#table_select_all").click(function() {
		if($("#table_select_all").prop('checked')){
			$("#table_body :checkbox").prop("checked",true);
		}else{
			$("#table_body :checkbox").prop("checked",false);
		}

	});

	//增加角色
	$("#add").click(function() {
		//打开模态窗前，清空输入值和错误提示
		$("#input_role_name").val("");
		$("#input_role_model").val("");
		$("#input_memo").val("");
		
		$("label.text-error").hide();
		$(".text-error").removeClass("text-error");
		$("#myModalLabel").text("增加角色");
		$('#input_role_model').multiselect('deselectAll', false);
        $('#input_role_model').multiselect('updateButtonText');
		$("#modal_edit").modal('show');
	});

	//修改角色
	$("#edit").click(function() {
		if(getSelectIds().length!=1){
			bootbox.alert({
    		    message: "必须且只能选择一条数据！",
    		    buttons: {
    		        ok: {
    		            label: '确定'
    		        }
    		    }
    		});
			return false;
		}
		var data =getSelectRole();
		//打开模态窗前，清空输入值和错误提示
		$("#input_role_name").val(data.roleName);
		$("#input_role_model").val("");
		$("#input_memo").val(data.memo);

		$("label.text-error").hide();
		$(".text-error").removeClass("text-error");
		$("#myModalLabel").text("修改角色");
		$('#input_role_model').multiselect('deselectAll', false);
        $('#input_role_model').multiselect('updateButtonText');
        $.ajax({
            type: "post",
            url: utils.api_path+"authority/getRoleModelList",
            dataType: "json",
            contentType: "application/json;charset=utf-8",
            data:JSON.stringify({roleId:getSelectRole().roleId}),
            success: function (data) {
            	if(data.code==0){
            		var sel=[];
            		for(var i=0;i<data.obj.length;i++){
            			if(data.obj[i].enabled==0){
            			}else{
            				sel.push(data.obj[i].modelId);
            			}
            			$('#input_role_model').multiselect('select', sel);
            		}

            		$("#modal_edit").modal('show');
            	}else{
            		bootbox.alert({
            		    message: data.message,
            		    buttons: {
            		        ok: {
            		            label: '确定'
            		        }
            		    }
            		});
            	}
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
            	bootbox.alert({
        		    message: "获取角色权限列表请求发生错误！",
        		    buttons: {
        		        ok: {
        		            label: '确定'
        		        }
        		    }
        		});
            }
        });
	});

	//删除角色
	$("#delete").click(function(){
		if(getSelectIds().length!=1){
			bootbox.alert({
    		    message: "必须且只能选择一条数据！",
    		    buttons: {
    		        ok: {
    		            label: '确定'
    		        }
    		    }
    		});
			return false;
		}

		bootbox.confirm({
		    title: "删除角色",
		    message: "选定角色将被删除，请确认",
		    buttons: {
		        cancel: {
		            label: '取消'
		        },
		        confirm: {
		            label: '确定'
		        }
		    },
		    callback: function (result) {
		        if(result){
		        	$.ajax({
				        type: "post",
				        url: utils.api_path+"authority/deleteRole",
				        dataType: "json",
				        contentType: "application/json;charset=utf-8",
				        data:JSON.stringify({roleId:getSelectRole().roleId}),
				        success: function (data) {
				        	if(data.code==0){
				        		//删除成功后重新检索
				        		getRoleList({pageNo:1});
				        	}else{
				        		bootbox.alert({
				        		    message: data.message,
				        		    buttons: {
				        		        ok: {
				        		            label: '确定'
				        		        }
				        		    }
				        		});
				        	}
				        },
				        error: function (XMLHttpRequest, textStatus, errorThrown) {
				        	bootbox.alert({
			        		    message: "删除角色请求发生错误！",
			        		    buttons: {
			        		        ok: {
			        		            label: '确定'
			        		        }
			        		    }
			        		});
				        }
				    });
		        }
		    }
		});
	});	

	//编辑模态窗表单
	$("#edit_form").validate({
		rules : {
			input_role_name : {
				required : true
			},
			input_role_model : {
				required : true
			},
			input_memo : {
				maxlength : 64
			}
		},
		errorClass:"text-error",
		onclick:false,
		onfocusout:false,
		onkeyup:false,
		messages : {
			input_role_name : {
				required : "请输入角色名"
			},
			input_role_model : {
				required : "请选择角色权限表"
			},
			input_memo : {
				maxlength : "最大长度64"
			}
		},
		success: function(label) {
		    console.log('success');
		},
		submitHandler : function(form) {
			var params={
					roleName :$("#input_role_name").val(),
					memo :$("#input_memo").val(),
					roleModelIds:$("#input_role_model").val().join(',')
	    	};
	    	if($("#myModalLabel").text()=="增加角色"){
	    		$.ajax({
			        type: "post",
			        url: utils.api_path+"authority/addRole",
			        dataType: "json",
			        contentType: "application/json;charset=utf-8",
			        data:JSON.stringify(params),
			        success: function (data) {
			        	if(data.code==0){
			        		$("#modal_edit").modal('hide');
			        		//重新检索
			        		getRoleList({pageNo:1});
			        	}else{
			        		bootbox.alert({
			        		    message: data.message,
			        		    buttons: {
			        		        ok: {
			        		            label: '确定'
			        		        }
			        		    }
			        		});
			        	}
			        },
			        error: function (XMLHttpRequest, textStatus, errorThrown) {
			        	bootbox.alert({
		        		    message: "增加角色请求发生错误！",
		        		    buttons: {
		        		        ok: {
		        		            label: '确定'
		        		        }
		        		    }
		        		});
			        }
			    });
	    	}else{
	    		$.ajax({
			        type: "post",
			        url: utils.api_path+"authority/modifyRole",
			        dataType: "json",
			        contentType: "application/json;charset=utf-8",
			        data:JSON.stringify($.extend(params,{roleId:getSelectRole().roleId})),
			        success: function (data) {
			        	if(data.code==0){
			        		$("#modal_edit").modal('hide');
			        		//重新检索
			        		getRoleList({pageNo:1});
			        	}else{
			        		bootbox.alert({
			        		    message: data.message,
			        		    buttons: {
			        		        ok: {
			        		            label: '确定'
			        		        }
			        		    }
			        		});
			        	}
			        },
			        error: function (XMLHttpRequest, textStatus, errorThrown) {
			        	bootbox.alert({
		        		    message: "修改用户请求发生错误！",
		        		    buttons: {
		        		        ok: {
		        		            label: '确定'
		        		        }
		        		    }
		        		});
			        }
			    });
	    	}
	    }
	});

	//查询表单
	$("#search_form").validate({
		rules : {
		},
		errorClass:"text-error",
		messages : {
		},
		submitHandler : function(form) {
			getRoleList({pageNo:1});
		}
	});

	//改变每页件数，触发查询
	$("#per_page").change(function() {
		getRoleList({pageNo:1});
	});

	//下拉列表选项
	$.ajax({
        type: "post",
        url: utils.api_path+"authority/getRoleModelList",
        dataType: "json",
        contentType: "application/json;charset=utf-8",
        success: function (data) {
        	if(data.code==0){
        		for(var i=0;i<data.obj.length;i++){
        			if(data.obj[i].enabled==0){
        				$('#input_role_model').append('<option value="'+data.obj[i].modelId+'">'+data.obj[i].modelName+'</option>');
        			}else{
        				$('#input_role_model').append('<option selected="selected" value="'+data.obj[i].modelId+'">'+data.obj[i].modelName+'</option>');
        			}
        			
        		}
        		$('#input_role_model').multiselect({
        			 nonSelectedText:'选择角色的权限',
        			 nSelectedText: ' - 个权限!',
        			 allSelectedText: '全部选中',
        			 numberDisplayed: 4
        		});
        	}else{
        		bootbox.alert({
        		    message: data.message,
        		    buttons: {
        		        ok: {
        		            label: '确定'
        		        }
        		    }
        		});
        	}
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
        	bootbox.alert({
    		    message: "获取角色权限列表请求发生错误！",
    		    buttons: {
    		        ok: {
    		            label: '确定'
    		        }
    		    }
    		});
        }
    });
	
	utils.setOptions("per_page","pageSize");

	//初期查询
	getRoleList({pageNo:1});
});