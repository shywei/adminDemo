utils.getMenu("点名管理","工间点名");

//检索
function getRollCallDetails(con){
	//获取当日工间点名信息列表
	var params ={
			rollCallId:sessionStorage.rollCallId,
			pageSize:$("#per_page").val(),
		};
	$.ajax({
		type: "post",
		url: utils.api_path+"rollCall/getRollCallDetails",
		dataType: "json",
		contentType: "application/json;charset=utf-8",
		data:JSON.stringify($.extend(params,con)),
		success: function (data) {
			if(data.code==0){
				var detailList=data.obj;
				if(detailList.results.length==0){
					bootbox.alert({
						message: "没有数据!",
						buttons: {
							ok: {
								label: '确定'
							}
						},
						callback:function(){
							window.open('workRollCall.html','_self');
						}
					});
					return;
				}

				$("#table_body").empty();
				//表格显示
				for(var i =0;i<detailList.results.length;i++){
					var rollCallData=detailList.results[i];
					$("#table_body").append('<tr><td>'+rollCallData.officalNumber+'</td><td>'+rollCallData.userName+'</td><td>'+rollCallData.rollCallStatus
							+'</td><td>'+rollCallData.memo+'</td><td>'+rollCallData.rollCallLocation+'</td><td>'+rollCallData.rollCallTime+'</td></tr>');
				}

				$('#paging').paging({
					initPageNo : detailList.page.currentPage, // 初始页码
					totalPages : detailList.page.pageCount, //总页数
					totalCount : '合计' + detailList.page.recordCount + '条数据', // 条目总数
					jump : true //是否支持跳转
				});

				$("#firstPage").click(function() {
					getRollCallList({pageNo:1});
				});
				$("#prePage").click(function() {
					getRollCallList({pageNo:detailList.page.currentPage-1});
				});
				$("#nextPage").click(function() {
					getRollCallList({pageNo:detailList.page.currentPage+1});
				});
				$("#lastPage").click(function() {
					getRollCallList({pageNo:detailList.page.pageCount});
				});
				$("#jumpBtn").click(function() {
					getRollCallList({pageNo:$("#jumpText").val()});
				});
				$("#pageSelect li").click(function() {
					getRollCallList({pageNo:$(this).text()});
				});
			}else{
				bootbox.alert({
					message: data.message,
					buttons: {
						ok: {
							label: '确定'
						}
					},
					callback:function(){
						window.open('workRollCall.html','_self');
					}
				});
			}
		},
		error: function (XMLHttpRequest, textStatus, errorThrown) {
			bootbox.alert({
				message: "获取当日工间点名信息列表请求发生错误",
				buttons: {
					ok: {
						label: '确定'
					}
				},
				callback:function(){
					window.open('workRollCall.html','_self');
				}
			});
		}
	});
}

$(document).ready(function() {
	//改变每页件数，触发查询
	$("#per_page").change(function() {
		getRollCallDetails({pageNo:1});
	});

	utils.setOptions("per_page","pageSize");
	var rollCallList=JSON.parse(sessionStorage.getItem("rollCallList"));
	for(var i =0;i<rollCallList.results.length;i++){
		if(rollCallList.results[i].id==sessionStorage.rollCallId){
			var rollCallData=rollCallList.results[i];
			$("#start_time").text(rollCallData.startTime);
			$("#extant_num").text(rollCallData.extantNum);
			$("#roll_call_num").text(rollCallData.rollCallNum);
			$("#attend_num").text(rollCallData.attendNum);
			$("#absent_num").text(rollCallData.absentNum);
			break;
		}
	}

	//初期查询
	getRollCallDetails({pageNo:1});
});
