utils.getMenu("","");
$(document).ready(function() {
    	//返回之前的页面
	    $("#cancel").click(function() {
	    	history.go(-1);
		});

	    //输入检查
	    $("#edit_form").validate({
			rules : {
				old_password : {
					required : true,
					maxlength : 20
				},
				new_password : {
					required : true,
					maxlength : 20
				},
				repeat_new_password : {
					required : true,
					equalTo : "#new_password"
				}
			},
			errorClass:"text-error",
			messages : {
				old_password : {
					required : "请输入旧密码",
					maxlength : "最大长度20"
				},
				new_password : {
					required : "请输入新密码",
					maxlength : "最大长度20"
				},
				repeat_new_password : {
					required : "请重复新密码",
					equalTo : "两次输入的密码不同"
				}
			},
			submitHandler : function(form) {
				$("#error_area").empty();
				//修改密码
				$.ajax({
			        type: "post",
			        url: utils.api_path+"systemUser/modifySystemUserPassword",
			        dataType: "json",
			        contentType: "application/json;charset=utf-8",
			        data:JSON.stringify({systemUserId:JSON.parse(sessionStorage.userInfo).id,
			        	oldPassword:$("#old_password").val(),
			        	newPassword:$("#new_password").val()
			        }),
			        success: function (data) {
			        	if(data.code==0){
			        		bootbox.alert({
			        		    message: "密码修改成功！",
			        		    buttons: {
			        		        ok: {
			        		            label: '确定'
			        		        }
			        		    },
			        		    callback: function (result) {
					        		window.location.href='welcom.html';
			        		    }
			        		});
			        	}else{
							$("#error_area").append(
									'<div class="alert alert-danger alert-dismissable"><a class="close" data-dismiss="alert" href="#">× </a> <iclass="icon-remove-sign"></i><span id="error_msg">'
									+data.message+'</span></div>');
			        	}
			        },
			        error: function (XMLHttpRequest, textStatus, errorThrown) {
			        	bootbox.alert({
		        		    message: "修改密码请求发生错误！",
		        		    buttons: {
		        		        ok: {
		        		            label: '确定'
		        		        }
		        		    }
		        		});
			        }
			    });
			}
		});

    });