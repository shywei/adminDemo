var logList=null;
utils.getMenu("日志管理","日志记录");

//检索
function getLogList(con){
	logList=null;
	//获取日志列表
	var params ={
			operationTime:$("#operation_time").val(),
			operatorId:$("#operator_name").val(),
			pageSize:$("#per_page").val(),
		};
	$.ajax({
		type: "post",
		url: utils.api_path+"opLog/getOpLog",
		dataType: "json",
		contentType: "application/json;charset=utf-8",
		data:JSON.stringify($.extend(params,con)),
		success: function (data) {
			if(data.code==0){
				logList=data.obj;
				if(logList.results.length==0){
					$("#data_area").hide();
					$("#no_data").show();
					return;
				}
				$("#table_select_all").prop('checked',false);
				$("#data_area").show();
				$("#no_data").hide();

				$("#table_body").empty();
				//表格显示
				for(var i =0;i<logList.results.length;i++){
					var log_data=logList.results[i];
					$("#table_body").append('<tr><td>'+log_data.operationTime+'</td><td>'+log_data.deptName
							+'</td><td>'+log_data.operatorName+'</td><td>'+log_data.operationContext+'</td></tr>');
				}

				$('#paging').paging({
					initPageNo : logList.page.currentPage, // 初始页码
					totalPages : logList.page.pageCount, //总页数
					totalCount : '合计' + logList.page.recordCount + '条数据', // 条目总数
					jump : true //是否支持跳转
				});

				$("#firstPage").click(function() {
					getLogList({pageNo:1});
				});
				$("#prePage").click(function() {
					getLogList({pageNo:logList.page.currentPage-1});
				});
				$("#nextPage").click(function() {
					getLogList({pageNo:logList.page.currentPage+1});
				});
				$("#lastPage").click(function() {
					getLogList({pageNo:logList.page.pageCount});
				});
				$("#jumpBtn").click(function() {
					getLogList({pageNo:$("#jumpText").val()});
				});
				$("#pageSelect li").click(function() {
					getLogList({pageNo:$(this).text()});
				});
			}else{
				$("#data_area").hide();
				$("#no_data").hide();
				bootbox.alert({
					message: data.message,
					buttons: {
						ok: {
							label: '确定'
						}
					}
				});
			}
		},
		error: function (XMLHttpRequest, textStatus, errorThrown) {
			$("#data_area").hide();
			$("#no_data").hide();
			bootbox.alert({
				message: "获取操作记录请求发生错误",
				buttons: {
					ok: {
						label: '确定'
					}
				}
			});
		}
	});
}


$(document).ready(function() {
	//日历控件初始化
	$('.form_date').datetimepicker({
		language:  'zh-CN',
		weekStart: 1,
		todayBtn:  1,
		autoclose: 1,
		todayHighlight: 1,
		startView: 2,
		minView: 2,
		forceParse: 0
	});

	//查询表单
	$("#search_form").validate({
		rules : {
		},
		errorClass:"text-error",
		messages : {
		},
		submitHandler : function(form) {
			getLogList({pageNo:1});
		}
	});

	//改变每页件数，触发查询
	$("#per_page").change(function() {
		getLogList({pageNo:1});
	});

	//下拉列表选项
	utils.setOptions("per_page","pageSize");

	//初期查询
	getLogList({pageNo:1});
});