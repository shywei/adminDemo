$(document).ready(function() {
		//获取字典集
		function getDict(){
			$.ajax({
		        type: "post",
		        url: utils.api_path+"user/getUserFields",
		        dataType: "json",
		        success: function (data) {
		        	if(data.code==0){
		        		for(var i=0;i<data.obj.length;i++){
		        			sessionStorage.setItem(data.obj[i].field,JSON.stringify(data.obj[i]));
		        		}
		        	}else{
		        		bootbox.alert({
		        		    message: data.message,
		        		    buttons: {
		        		        ok: {
		        		            label: '确定'
		        		        }
		        		    }
		        		});
		        	}
		        },
		        error: function (XMLHttpRequest, textStatus, errorThrown) {
		        	bootbox.alert({
	        		    message: "获取字典请求发生错误！",
	        		    buttons: {
	        		        ok: {
	        		            label: '确定'
	        		        }
	        		    }
	        		});
		        }
		    });
		}

    	//获取验证码
    	function getVerify(){
    		$.ajax({
		        type: "post",
		        url: utils.api_path+"systemUser/randomNum",
		        dataType: "json",
		        success: function (data) {
		        	if(data.code==0){
		        		$('#verification').text(data.obj);
		        		$('#hidden_verification').val(data.obj);
		        	}else{
		        		bootbox.alert({
		        		    message: data.message,
		        		    buttons: {
		        		        ok: {
		        		            label: '确定'
		        		        }
		        		    }
		        		});
		        	}
		        },
		        error: function (XMLHttpRequest, textStatus, errorThrown) {
		        	bootbox.alert({
	        		    message: "获取验证码请求发生错误！",
	        		    buttons: {
	        		        ok: {
	        		            label: '确定'
	        		        }
	        		    }
	        		});
		        }
		    });
    	}

    	//重新获取验证码
	    $("#verification").click(function() {
	    	getVerify();
		});

	    //登录时输入检查
	    $("#login_form").validate({
			rules : {
				login_name : {
					required : true,
					maxlength : 20
				},
				password : {
					required : true,
					maxlength : 20
				},
				input_verification : {
					required : true,
					equalTo : "#hidden_verification"
				}
			},
			errorClass:"text-error",
			messages : {
				login_name : {
					required : "请输入用户名",
					maxlength : "最大长度20"
				},
				password : {
					required : "请输入密码",
					maxlength : "最大长度20"
				},
				input_verification : {
					required : "请输入验证码",
					equalTo : "验证码不正确"
				}
			},
			submitHandler : function(form) {
				//登录
				$.ajax({
			        type: "post",
			        url: utils.api_path+"systemUser/login",
			        dataType: "json",
			        contentType: "application/json;charset=utf-8",
			        data:JSON.stringify({loginName:$("#login_name").val(),
			        	password:$("#password").val()
			        }),
			        success: function (data) {
			        	if(data.code==0){
			        		sessionStorage.setItem("userInfo",JSON.stringify(data.obj));
			        		//获取菜单
			        		$.ajax({
			        	        type: "post",
			        	        url: utils.api_path+"authority/getMenuById",
			        	        dataType: "json",
			        	        contentType: "application/json;charset=utf-8",
			        	        data:JSON.stringify({loginUserId:JSON.parse(sessionStorage.userInfo).id
			        	        }),
			        	        success: function (data) {
			        	        	if(data.code==0){
			        	        		sessionStorage.setItem("menu",JSON.stringify(data));
						        		window.open('welcom.html','_self');
			        	        	}else{
			        	        		bootbox.alert({
			        	        		    message: data.message,
			        	        		    buttons: {
			        	        		        ok: {
			        	        		            label: '确定'
			        	        		        }
			        	        		    },
			        	        		    callback: function (result) {
			        	        		    }
			        	        		});
			        	        	}
			        	        },
			        	        error: function (XMLHttpRequest, textStatus, errorThrown) {
			        	        	bootbox.alert({
			        	    		    message: "获取菜单请求发生错误！",
			        	    		    buttons: {
			        	    		        ok: {
			        	    		            label: '确定'
			        	    		        }
			        	    		    }
			        	    		});
			        	        }
			        	    });

			        	}else{
			        		bootbox.alert({
			        		    message: data.message,
			        		    buttons: {
			        		        ok: {
			        		            label: '确定'
			        		        }
			        		    },
			        		    callback: function (result) {
			        		    	$("#login_name").val("");
			        		    	$("#password").val("");
			        		    	$("#input_verification").val("");
			        		    	getVerify();
			        		    }
			        		});
			        	}
			        },
			        error: function (XMLHttpRequest, textStatus, errorThrown) {
			        	bootbox.alert({
		        		    message: "登录请求发生错误！",
		        		    buttons: {
		        		        ok: {
		        		            label: '确定'
		        		        }
		        		    }
		        		});
			        }
			    });
			}
		});

	    //初始化时获取验证码
	    getVerify();
	    getDict();
    });