var sysUserList=null;
utils.getMenu("系统管理","系统用户管理");
utils.getDept(1);
utils.getRole();

//检索
function getSysUserList(con){
	sysUserList=null;
	//获取系统用户列表
	var params ={
			userName:$("#user_name").val(),
			policeNumber:$("#police_number").val(),
			deptId:$("#dept_id").val(),
			roleId:$("#role_id").val(),
			pageSize:$("#per_page").val(),
			hasMetacarpalVein:0
		};
	$.ajax({
		type: "post",
		url: utils.api_path+"systemUser/getSystemUserList",
		dataType: "json",
		contentType: "application/json;charset=utf-8",
		data:JSON.stringify($.extend(params,con)),
		success: function (data) {
			if(data.code==0){
				sysUserList=data.obj;
				if(sysUserList.results.length==0){
					$("#data_area").hide();
					$("#no_data").show();
					return;
				}
				$("#table_select_all").prop('checked',false);
				$("#data_area").show();
				$("#no_data").hide();

				$("#table_body").empty();
				//表格显示
				for(var i =0;i<sysUserList.results.length;i++){
					var user_data=sysUserList.results[i];
					$("#table_body").append('<tr><td><input type="checkbox" data-id="'+user_data.id+'"></td><td>'+user_data.policeNumber+'</td><td>'+user_data.userName+'</td><td>'+user_data.loginName
							+'</td><td>'+utils.getRoleName(user_data.roleId)+'</td><td>'+user_data.createTime+'</td><td>'+user_data.updateTime+'</td><td>'+utils.getDeptName(user_data.deptId)
							+'</td><td>'+utils.getOptionName("hasMetacarpalVein", user_data.hasMetacarpalVein)+'</td></tr>');
				}

				$('#paging').paging({
					initPageNo : sysUserList.page.currentPage, // 初始页码
					totalPages : sysUserList.page.pageCount, //总页数
					totalCount : '合计' + sysUserList.page.recordCount + '条数据', // 条目总数
					jump : true //是否支持跳转
				});

				$("#firstPage").click(function() {
					getSysUserList({pageNo:1});
				});
				$("#prePage").click(function() {
					getSysUserList({pageNo:sysUserList.page.currentPage-1});
				});
				$("#nextPage").click(function() {
					getSysUserList({pageNo:sysUserList.page.currentPage+1});
				});
				$("#lastPage").click(function() {
					getSysUserList({pageNo:sysUserList.page.pageCount});
				});
				$("#jumpBtn").click(function() {
					getSysUserList({pageNo:$("#jumpText").val()});
				});
				$("#pageSelect li").click(function() {
					getSysUserList({pageNo:$(this).text()});
				});
			}else{
				$("#data_area").hide();
				$("#no_data").hide();
				bootbox.alert({
					message: data.message,
					buttons: {
						ok: {
							label: '确定'
						}
					}
				});
			}
		},
		error: function (XMLHttpRequest, textStatus, errorThrown) {
			$("#data_area").hide();
			$("#no_data").hide();
			bootbox.alert({
				message: "获取系统用户列表请求发生错误",
				buttons: {
					ok: {
						label: '确定'
					}
				}
			});
		}
	});
}

//获取选中的id
function getSelectIds(){
	var ids=[];
	if(sysUserList.results.length==0){
		return ids;
	}
	$("#table_body :checked").each(function(){
	    ids.push($(this).data("id"));
	  });
	return ids;
}

//获取选中的用户信息
function getSelectUser(){
	var ids=getSelectIds();
	for(var i=0;i<sysUserList.results.length;i++){
		if(sysUserList.results[i].id==ids[0]){
			return sysUserList.results[i];
		}
	}
}

$(document).ready(function() {
	//表格全选
	$("#table_select_all").click(function() {
		if($("#table_select_all").prop('checked')){
			$("#table_body :checkbox").prop("checked",true);
		}else{
			$("#table_body :checkbox").prop("checked",false);
		}

	});

	//注册用户
	$("#add").click(function() {
		//打开模态窗前，清空输入值和错误提示
		$("#input_login_name").val("");
		$("#input_user_name").val("");
		$("#input_police_number").val("");
		$("#input_password").val("");
		$("#pass_area").show();
		$("#input_role_id").val("");
		$("#input_re_pass").val("");
		$("#input_organization").val("");
		$("#input_position").val("");
		$("#input_dept_id").val("");
		$("#input_veinData").val("");
		
		$("label.text-error").hide();
		$(".text-error").removeClass("text-error");
		$("#myModalLabel").text("注册用户");

		$("#modal_edit").modal('show');
	});

	//修改用户
	$("#edit").click(function() {
		if(getSelectIds().length!=1){
			bootbox.alert({
    		    message: "必须且只能选择一条数据！",
    		    buttons: {
    		        ok: {
    		            label: '确定'
    		        }
    		    }
    		});
			return false;
		}
		var data =getSelectUser();
		//打开模态窗前，清空输入值和错误提示
		$("#input_login_name").val(data.loginName);
		$("#input_login_name").attr("disabled",true);
		$("#input_user_name").val(data.userName);
		$("#input_police_number").val(data.policeNumber);
		$("#pass_area").hide();
		$("#input_role_id").val(data.roleId);
		$("#input_organization").val(data.organization);
		$("#input_position").val(data.position);
		$("#input_dept_id").val(data.deptId);
		$("#input_veinData").val("");

		$("label.text-error").hide();
		$(".text-error").removeClass("text-error");
		$("#myModalLabel").text("修改用户");

		$("#modal_edit").modal('show');
	});

	//删除用户
	$("#delete").click(function(){
		if(getSelectIds().length==0){
			bootbox.alert({
    		    message: "未选中任何用户！",
    		    buttons: {
    		        ok: {
    		            label: '确定'
    		        }
    		    }
    		});
			return false;
		}

		bootbox.confirm({
		    title: "删除用户",
		    message: "选定用户将被删除，请确认",
		    buttons: {
		        cancel: {
		            label: '取消'
		        },
		        confirm: {
		            label: '确定'
		        }
		    },
		    callback: function (result) {
		        if(result){
		        	$.ajax({
				        type: "post",
				        url: utils.api_path+"systemUser/deleteSystemUser",
				        dataType: "json",
				        contentType: "application/json;charset=utf-8",
				        data:JSON.stringify({systemUserIds:getSelectIds().join(",")}),
				        success: function (data) {
				        	if(data.code==0){
				        		//删除成功后重新检索
				        		getSysUserList({pageNo:1});
				        	}else{
				        		bootbox.alert({
				        		    message: data.message,
				        		    buttons: {
				        		        ok: {
				        		            label: '确定'
				        		        }
				        		    }
				        		});
				        	}
				        },
				        error: function (XMLHttpRequest, textStatus, errorThrown) {
				        	bootbox.alert({
			        		    message: "删除用户请求发生错误！",
			        		    buttons: {
			        		        ok: {
			        		            label: '确定'
			        		        }
			        		    }
			        		});
				        }
				    });
		        }
		    }
		});
	});
	
	//初始化密码
	$("#init_pass").click(function(){
		if(getSelectIds().length!=1){
			bootbox.alert({
    		    message: "必须且只能选择一条数据！",
    		    buttons: {
    		        ok: {
    		            label: '确定'
    		        }
    		    }
    		});
			return false;
		}

		bootbox.confirm({
		    title: "初始化密码",
		    message: "选定用户将初始化密码，请确认",
		    buttons: {
		        cancel: {
		            label: '取消'
		        },
		        confirm: {
		            label: '确定'
		        }
		    },
		    callback: function (result) {
		        if(result){
		        	$.ajax({
				        type: "post",
				        url: utils.api_path+"systemUser/resetSystemUserPassword",
				        dataType: "json",
				        contentType: "application/json;charset=utf-8",
				        data:JSON.stringify({systemUserId:getSelectUser().id}),
				        success: function (data) {
				        	if(data.code==0){
				        		//重新检索
				        		getSysUserList({pageNo:1});
				        	}else{
				        		bootbox.alert({
				        		    message: data.message,
				        		    buttons: {
				        		        ok: {
				        		            label: '确定'
				        		        }
				        		    }
				        		});
				        	}
				        },
				        error: function (XMLHttpRequest, textStatus, errorThrown) {
				        	bootbox.alert({
			        		    message: "初始化密码请求发生错误！",
			        		    buttons: {
			        		        ok: {
			        		            label: '确定'
			        		        }
			        		    }
			        		});
				        }
				    });
		        }
		    }
		});
	});

	//编辑模态窗表单
	$("#edit_form").validate({
		rules : {
			input_login_name : {
				required : true
			},
			input_user_name : {
				required : true
			},
			input_police_number : {
				required : true
			},
			input_role_id : {
				required : true
			},
			input_password : {
				required : true
			},
			input_re_pass : {
				required : true
			},
			input_organization : {
				required : true
			},
			input_position : {
				required : true
			},
			input_dept_id : {
				required : true
			}
		},
		errorClass:"text-error",
		onclick:false,
		onfocusout:false,
		onkeyup:false,
		messages : {
			input_login_name : {
				required : "请输入系统账号"
			},
			input_user_name : {
				required : "请输入真实姓名"
			},
			input_police_number : {
				required : "请输入警号"
			},
			input_role_id : {
				required : "请选择角色"
			},
			input_password : {
				required : "请输入密码"
			},
			input_re_pass : {
				required : "请输入相同的密码"
			},
			input_organization : {
				required : "请输入部门"
			},
			input_position : {
				required : "请输入岗位"
			},
			input_dept_id : {
				required : "请选择管理域"
			}
		},
		success: function(label) {
		    console.log('success');
		},
		submitHandler : function(form) {
			var params={
					loginName :$("#input_login_name").val(),
					userName :$("#input_user_name").val(),
					policeNumber :$("#input_police_number").val(),
					roleId :$("#input_role_id").val(),
					organization :$("#input_organization").val(),
					position :$("#input_position").val(),
					metacarpalVein:$("#veinData").val(),
					deptId  :$("#input_dept_id").val()
	    	};
	    	if($("#myModalLabel").text()=="注册设备"){
	    		$.ajax({
			        type: "post",
			        url: utils.api_path+"systemUser/addSystemUser",
			        dataType: "json",
			        contentType: "application/json;charset=utf-8",
			        data:JSON.stringify($.extend(params,{password :$("#input_password").val()})),
			        success: function (data) {
			        	if(data.code==0){
			        		$("#modal_edit").modal('hide');
			        		//重新检索
			        		getSysUserList({pageNo:1});
			        	}else{
			        		bootbox.alert({
			        		    message: data.message,
			        		    buttons: {
			        		        ok: {
			        		            label: '确定'
			        		        }
			        		    }
			        		});
			        	}
			        },
			        error: function (XMLHttpRequest, textStatus, errorThrown) {
			        	bootbox.alert({
		        		    message: "注册用户请求发生错误！",
		        		    buttons: {
		        		        ok: {
		        		            label: '确定'
		        		        }
		        		    }
		        		});
			        }
			    });
	    	}else{
	    		$.ajax({
			        type: "post",
			        url: utils.api_path+"systemUser/modifySystemUser",
			        dataType: "json",
			        contentType: "application/json;charset=utf-8",
			        data:JSON.stringify($.extend(params,{id:getSelectUser().id})),
			        success: function (data) {
			        	if(data.code==0){
			        		$("#modal_edit").modal('hide');
			        		//重新检索
			        		getSysUserList({pageNo:1});
			        	}else{
			        		bootbox.alert({
			        		    message: data.message,
			        		    buttons: {
			        		        ok: {
			        		            label: '确定'
			        		        }
			        		    }
			        		});
			        	}
			        },
			        error: function (XMLHttpRequest, textStatus, errorThrown) {
			        	bootbox.alert({
		        		    message: "修改用户请求发生错误！",
		        		    buttons: {
		        		        ok: {
		        		            label: '确定'
		        		        }
		        		    }
		        		});
			        }
			    });
	    	}
	    }
	});

	//查询表单
	$("#search_form").validate({
		rules : {
		},
		errorClass:"text-error",
		messages : {
		},
		submitHandler : function(form) {
			getSysUserList({pageNo:1});
		}
	});

	//改变每页件数，触发查询
	$("#per_page").change(function() {
		getSysUserList({pageNo:1});
	});

	//下拉列表选项
	utils.setDeptOptions("dept_id");
	utils.setDeptOptions("input_dept_id");
	utils.setRoleOptions("role_id");
	utils.setRoleOptions("input_role_id");
	utils.setOptions("per_page","pageSize");

	//初期查询
	getSysUserList({pageNo:1});
});