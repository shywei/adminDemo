var deviceList=null;
utils.getMenu("设备管理","管理设备");
utils.getArea();

//检索
function getDeviceList(con){
	deviceList=null;
	//获取设备列表
	var params ={
			deviceName:$("#device_name").val(),
			deviceId:$("#device_id").val(),
			deviceIp :$("#device_ip").val(),
			pageSize:$("#per_page").val(),
		};
	$.ajax({
		type: "post",
		url: utils.api_path+"device/getDeviceList",
		dataType: "json",
		contentType: "application/json;charset=utf-8",
		data:JSON.stringify($.extend(params,con)),
		success: function (data) {
			if(data.code==0){
				deviceList=data.obj;
				if(deviceList.results.length==0){
					$("#data_area").hide();
					$("#no_data").show();
					return;
				}
				$("#table_select_all").prop('checked',false);
				$("#data_area").show();
				$("#no_data").hide();

				$("#table_body").empty();
				//表格显示
				for(var i =0;i<deviceList.results.length;i++){
					var device_data=deviceList.results[i];
					$("#table_body").append('<tr><td><input type="checkbox" data-id="'+device_data.deviceId+'"></td><td>'+device_data.deviceId+'</td><td>'+device_data.deviceName+'</td><td>'+device_data.deviceIp
							+'</td><td>'+utils.getOptionName("deviceModel",device_data.deviceModel)+'</td><td>'+device_data.devicePort+'</td><td>'+device_data.serverIp+'</td><td>'+utils.getOptionName("applicationModel", device_data.applicationModel)
							+'</td><td>'+utils.getAreaName( device_data.areaId)+'</td></tr>');
				}

				$('#paging').paging({
					initPageNo : deviceList.page.currentPage, // 初始页码
					totalPages : deviceList.page.pageCount, //总页数
					totalCount : '合计' + deviceList.page.recordCount + '条数据', // 条目总数
					jump : true //是否支持跳转
				});

				$("#firstPage").click(function() {
					getDeviceList({pageNo:1});
				});
				$("#prePage").click(function() {
					getDeviceList({pageNo:deviceList.page.currentPage-1});
				});
				$("#nextPage").click(function() {
					getDeviceList({pageNo:deviceList.page.currentPage+1});
				});
				$("#lastPage").click(function() {
					getDeviceList({pageNo:deviceList.page.pageCount});
				});
				$("#jumpBtn").click(function() {
					getDeviceList({pageNo:$("#jumpText").val()});
				});
				$("#pageSelect li").click(function() {
					getDeviceList({pageNo:$(this).text()});
				});
			}else{
				$("#data_area").hide();
				$("#no_data").hide();
				bootbox.alert({
					message: data.message,
					buttons: {
						ok: {
							label: '确定'
						}
					}
				});
			}
		},
		error: function (XMLHttpRequest, textStatus, errorThrown) {
			$("#data_area").hide();
			$("#no_data").hide();
			bootbox.alert({
				message: "获取设备列表请求发生错误",
				buttons: {
					ok: {
						label: '确定'
					}
				}
			});
		}
	});
}

//获取选中的id
function getSelectIds(){
	var ids=[];
	if(deviceList.results.length==0){
		return ids;
	}
	$("#table_body :checked").each(function(){
	    ids.push($(this).data("id"));
	  });
	return ids;
}

//获取选中的设备信息
function getSelectDevice(){
	var ids=getSelectIds();
	for(var i=0;i<deviceList.results.length;i++){
		if(deviceList.results[i].deviceId==ids[0]){
			return deviceList.results[i];
		}
	}
}

$(document).ready(function() {
	//表格全选
	$("#table_select_all").click(function() {
		if($("#table_select_all").prop('checked')){
			$("#table_body :checkbox").prop("checked",true);
		}else{
			$("#table_body :checkbox").prop("checked",false);
		}

	});

	//添加设备
	$("#add").click(function() {
		//打开模态窗前，清空输入值和错误提示
		$("#input_device_name").val("");
		$("#input_device_id").val("");
		$("#input_device_port").val("");
		$("#input_password").val("");
		$("#input_device_ip").val("");
		$("#input_server_ip").val("");
		$("#input_device_model").val("");
		$("#input_application_model").val("");
		$("#input_area_id").val("");

		$("label.text-error").hide();
		$(".text-error").removeClass("text-error");
		$("#myModalLabel").text("注册设备");

		$("#modal_edit").modal('show');
	});

	//修改设备
	$("#edit").click(function() {
		if(getSelectIds().length!=1){
			bootbox.alert({
    		    message: "必须且只能选择一条数据！",
    		    buttons: {
    		        ok: {
    		            label: '确定'
    		        }
    		    }
    		});
			return false;
		}
		var data =getSelectDevice();
		//打开模态窗前，清空输入值和错误提示
		$("#input_device_name").val(data.deviceName);
		$("#input_device_id").val(data.deviceId);
		$("#input_device_port").val(data.devicePort);
		$("#input_password").val(data.password);
		$("#input_device_ip").val(data.deviceIp);
		$("#input_server_ip").val(data.serverIp);
		$("#input_device_model").val(data.deviceModel);
		$("#input_application_model").val(data.applicationModel);
		$("#input_area_id").val(data.areaId);

		$("label.text-error").hide();
		$(".text-error").removeClass("text-error");
		$("#myModalLabel").text("修改设备");

		$("#modal_edit").modal('show');
	});

	//删除设备
	$("#delete").click(function(){
		if(getSelectIds().length==0){
			bootbox.alert({
    		    message: "未选中任何设备！",
    		    buttons: {
    		        ok: {
    		            label: '确定'
    		        }
    		    }
    		});
			return false;
		}

		bootbox.confirm({
		    title: "删除设备",
		    message: "选定设备将被删除，请确认",
		    buttons: {
		        cancel: {
		            label: '取消'
		        },
		        confirm: {
		            label: '确定'
		        }
		    },
		    callback: function (result) {
		        if(result){
		        	$.ajax({
				        type: "post",
				        url: utils.api_path+"device/deleteDevice",
				        dataType: "json",
				        contentType: "application/json;charset=utf-8",
				        data:JSON.stringify({deviceIds:getSelectIds().join(",")}),
				        success: function (data) {
				        	if(data.code==0){
				        		//删除成功后重新检索
				        		getDeviceList({pageNo:1});
				        	}else{
				        		bootbox.alert({
				        		    message: data.message,
				        		    buttons: {
				        		        ok: {
				        		            label: '确定'
				        		        }
				        		    }
				        		});
				        	}
				        },
				        error: function (XMLHttpRequest, textStatus, errorThrown) {
				        	bootbox.alert({
			        		    message: "删除设备请求发生错误！",
			        		    buttons: {
			        		        ok: {
			        		            label: '确定'
			        		        }
			        		    }
			        		});
				        }
				    });
		        }
		    }
		});
	});

	//编辑模态窗表单
	$("#edit_form").validate({
		rules : {
			input_device_name : {
				required : true
			},
			input_device_id : {
				required : true
			},
			input_device_port : {
				required : true
			},
			input_password : {
				required : true
			},
			input_device_ip : {
				required : true
			},
			input_server_ip : {
				required : true
			},
			input_device_model : {
				required : true
			},
			input_application_model : {
				required : true
			},
			input_area_id : {
				required : true
			}
		},
		errorClass:"text-error",
		onclick:false,
		onfocusout:false,
		onkeyup:false,
		messages : {
			input_device_name : {
				required : "请输入设备名称"
			},
			input_device_id : {
				required : "请输入设备编号"
			},
			input_device_port : {
				required : "请输入连接端口"
			},
			input_password : {
				required : "请输入连接密码"
			},
			input_device_ip : {
				required : "请输入设备IP"
			},
			input_server_ip : {
				required : "请输入服务器IP"
			},
			input_device_model : {
				required : "请选择设备类型"
			},
			input_application_model : {
				required : "请选择应用类型"
			},
			input_area_id : {
				required : "请选择设备位置"
			}
		},
		success: function(label) {
		    console.log('success');
		},
		submitHandler : function(form) {
			var params={
					deviceId:$("#input_device_id").val(),
					deviceName:$("#input_device_name").val(),
					deviceModel:$("#input_device_model").val(),
					deviceIp:$("#input_device_ip").val(),
					devicePort:$("#input_device_port").val(),
					serverIp:$("#input_server_ip").val(),
					password:$("#input_password").val(),
					areaId:$("#input_area_id").val(),
					applicationModel:$("#input_application_model").val()
	    	};
	    	if($("#myModalLabel").text()=="注册设备"){
	    		$.ajax({
			        type: "post",
			        url: utils.api_path+"device/addDevice",
			        dataType: "json",
			        contentType: "application/json;charset=utf-8",
			        data:JSON.stringify(params),
			        success: function (data) {
			        	if(data.code==0){
			        		$("#modal_edit").modal('hide');
			        		//重新检索
			        		getDeviceList({pageNo:1});
			        	}else{
			        		bootbox.alert({
			        		    message: data.message,
			        		    buttons: {
			        		        ok: {
			        		            label: '确定'
			        		        }
			        		    }
			        		});
			        	}
			        },
			        error: function (XMLHttpRequest, textStatus, errorThrown) {
			        	bootbox.alert({
		        		    message: "注册设备请求发生错误！",
		        		    buttons: {
		        		        ok: {
		        		            label: '确定'
		        		        }
		        		    }
		        		});
			        }
			    });
	    	}else{
	    		$.ajax({
			        type: "post",
			        url: utils.api_path+"device/modifyDevice",
			        dataType: "json",
			        contentType: "application/json;charset=utf-8",
			        data:JSON.stringify($.extend(params,{id:getSelectUser().id})),
			        success: function (data) {
			        	if(data.code==0){
			        		$("#modal_edit").modal('hide');
			        		//重新检索
			        		getDeviceList({pageNo:1});
			        	}else{
			        		bootbox.alert({
			        		    message: data.message,
			        		    buttons: {
			        		        ok: {
			        		            label: '确定'
			        		        }
			        		    }
			        		});
			        	}
			        },
			        error: function (XMLHttpRequest, textStatus, errorThrown) {
			        	bootbox.alert({
		        		    message: "修改设备请求发生错误！",
		        		    buttons: {
		        		        ok: {
		        		            label: '确定'
		        		        }
		        		    }
		        		});
			        }
			    });
	    	}
	    }
	});

	//查询表单
	$("#search_form").validate({
		rules : {
		},
		errorClass:"text-error",
		messages : {
		},
		submitHandler : function(form) {
			getDeviceList({pageNo:1});
		}
	});

	//改变每页件数，触发查询
	$("#per_page").change(function() {
		getDeviceList({pageNo:1});
	});

	//下拉列表选项
	utils.setOptions("input_device_model","deviceModel");
	utils.setOptions("input_application_model","applicationModel");
	utils.setOptions("per_page","pageSize");
	utils.setAreaOptions("input_area_id");

	//初期查询
	getDeviceList({pageNo:1});
});