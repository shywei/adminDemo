var sysUserList=null;
utils.getMenu("系统管理","系统用户管理");
utils.getDept(1);
utils.getRole();

//检索
function getSysUserList(con){
	sysUserList=null;
	//获取系统用户列表
	var params ={
			userName:$("#user_name").val(),
			policeNumber:$("#police_number").val(),
			deptId:$("#dept_id").val(),
			roleId:$("#role_id").val(),
			pageSize:$("#per_page").val(),
			hasMetacarpalVein:1
		};
	$.ajax({
		type: "post",
		url: utils.api_path+"systemUser/getSystemUserList",
		dataType: "json",
		contentType: "application/json;charset=utf-8",
		data:JSON.stringify($.extend(params,con)),
		success: function (data) {
			if(data.code==0){
				sysUserList=data.obj;
				if(sysUserList.results.length==0){
					$("#data_area").hide();
					$("#no_data").show();
					return;
				}
				$("#table_select_all").prop('checked',false);
				$("#data_area").show();
				$("#no_data").hide();

				$("#table_body").empty();
				//表格显示
				for(var i =0;i<sysUserList.results.length;i++){
					var user_data=sysUserList.results[i];
					$("#table_body").append('<tr><td><input type="checkbox" data-id="'+user_data.id+'"></td><td>'+user_data.policeNumber+'</td><td>'+user_data.userName+'</td><td>'+user_data.loginName
							+'</td><td>'+utils.getRoleName(user_data.roleId)+'</td><td>'+user_data.createTime+'</td><td>'+user_data.updateTime+'</td><td>'+utils.getDeptName(user_data.deptId)
							+'</td></tr>');
				}

				$('#paging').paging({
					initPageNo : sysUserList.page.currentPage, // 初始页码
					totalPages : sysUserList.page.pageCount, //总页数
					totalCount : '合计' + sysUserList.page.recordCount + '条数据', // 条目总数
					jump : true //是否支持跳转
				});

				$("#firstPage").click(function() {
					getSysUserList({pageNo:1});
				});
				$("#prePage").click(function() {
					getSysUserList({pageNo:sysUserList.page.currentPage-1});
				});
				$("#nextPage").click(function() {
					getSysUserList({pageNo:sysUserList.page.currentPage+1});
				});
				$("#lastPage").click(function() {
					getSysUserList({pageNo:sysUserList.page.pageCount});
				});
				$("#jumpBtn").click(function() {
					getSysUserList({pageNo:$("#jumpText").val()});
				});
				$("#pageSelect li").click(function() {
					getSysUserList({pageNo:$(this).text()});
				});
			}else{
				$("#data_area").hide();
				$("#no_data").hide();
				bootbox.alert({
					message: data.message,
					buttons: {
						ok: {
							label: '确定'
						}
					}
				});
			}
		},
		error: function (XMLHttpRequest, textStatus, errorThrown) {
			$("#data_area").hide();
			$("#no_data").hide();
			bootbox.alert({
				message: "获取系统用户列表请求发生错误",
				buttons: {
					ok: {
						label: '确定'
					}
				}
			});
		}
	});
}

//获取选中的id
function getSelectIds(){
	var ids=[];
	if(sysUserList.results.length==0){
		return ids;
	}
	$("#table_body :checked").each(function(){
	    ids.push($(this).data("id"));
	  });
	return ids;
}

//获取选中的用户信息
function getSelectUser(){
	var ids=getSelectIds();
	for(var i=0;i<sysUserList.results.length;i++){
		if(sysUserList.results[i].id==ids[0]){
			return sysUserList.results[i];
		}
	}
}

$(document).ready(function() {
	utils.getDeviceNameData();
	
	//表格全选
	$("#table_select_all").click(function() {
		if($("#table_select_all").prop('checked')){
			$("#table_body :checkbox").prop("checked",true);
		}else{
			$("#table_body :checkbox").prop("checked",false);
		}

	});
	
	//管理员下发
	$("#downloadAdmin").click(function() {
		if(getSelectIds().length==0){
			bootbox.alert({
    		    message: "未选中任何人员！",
    		    buttons: {
    		        ok: {
    		            label: '确定'
    		        }
    		    }
    		});
			return false;
		}
		var data =JSON.parse(sessionStorage.getItem("deviceNameData"));
		var options=[{
            text: '',
            value: '',
        }];
		for(var i=0;i<data.obj.length;i++){
			options.push({value:data.obj[i].deviceId,text:data.obj[i].deviceName,});
		}
		bootbox.prompt({
		    title: "管理员下发",
		    inputType: 'select',
		    inputOptions: options,
		    buttons: {
		        cancel: {
		            label: '取消'
		        },
		        confirm: {
		            label: '确定'
		        }
		    },
		    callback: function (result) {
		    	if(result==''){
		        	bootbox.alert({
	        		    message: "未选择设备！",
	        		    buttons: {
	        		        ok: {
	        		            label: '确定'
	        		        }
	        		    }
	        		});
		        }else if(result!=null){
		        	bootbox.confirm({
		    		    title: "管理员下发",
		    		    message: "下发操作将覆盖现有的掌静脉设备中的管理员数据。继续下发操作吗？",
		    		    buttons: {
		    		        cancel: {
		    		            label: '取消'
		    		        },
		    		        confirm: {
		    		            label: '确定'
		    		        }
		    		    },
		    		    callback: function (result2) {
		    		        if(result2){
		    		        	$.ajax({
		    				        type: "post",
		    				        url: utils.api_path+"authority/downloadAdmin",
		    				        dataType: "json",
		    				        contentType: "application/json;charset=utf-8",
		    				        data:JSON.stringify({systemUserIds:getSelectIds().join(","),deviceId:result}),
		    				        success: function (data) {
		    				        	if(data.code==0){
		    				        	}else{
		    				        		bootbox.alert({
		    				        		    message: data.message,
		    				        		    buttons: {
		    				        		        ok: {
		    				        		            label: '确定'
		    				        		        }
		    				        		    }
		    				        		});
		    				        	}
		    				        },
		    				        error: function (XMLHttpRequest, textStatus, errorThrown) {
		    				        	bootbox.alert({
		    			        		    message: "管理员下发请求发生错误！",
		    			        		    buttons: {
		    			        		        ok: {
		    			        		            label: '确定'
		    			        		        }
		    			        		    }
		    			        		});
		    				        }
		    				    });
		    		        }
		    		    }
		    		});
		        	
		        }
		    }
		});
	});

	//查询表单
	$("#search_form").validate({
		rules : {
		},
		errorClass:"text-error",
		messages : {
		},
		submitHandler : function(form) {
			getSysUserList({pageNo:1});
		}
	});

	//改变每页件数，触发查询
	$("#per_page").change(function() {
		getSysUserList({pageNo:1});
	});

	//下拉列表选项
	utils.setDeptOptions("dept_id");
	utils.setRoleOptions("role_id");
	utils.setOptions("per_page","pageSize");
	//初期查询
	getSysUserList({pageNo:1});
});